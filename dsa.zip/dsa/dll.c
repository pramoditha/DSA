#include<stdio.h>
#include<stdlib.h>
struct dll
{
	int data;
	struct dll *next;
	struct dll *prev;
};
struct dll *head=NULL;
void add(int);
void dis();
int del();
int xs,cs,k;
int main()
{
do
{
	printf("\n\n\n1.Add an element.");
	printf("\n2.Display  elements.");
	printf("\n3.Deleting element.");
	printf("\n4.Exit");
	printf("\nEnter your Choice:");
	scanf("%d",&xs);
	switch(xs)
	{
		case 1:printf("Enter an element to add:");
		scanf("%d",&cs);
		add(cs);
		break;
		case 2:dis();
		break;
		case 3:k=del();
		printf("\n%d is deleted\n",k);
		break;
		case 4:return -1;
		break;
	}
}while(xs!=4);
}
void add(int x)
{
	struct dll *tp;
	tp=(struct dll *)malloc(sizeof(struct dll));
	if(tp==NULL)
	{
		printf("\nDouble Linked List is full");
		return;
	}
	tp->data=x;
	tp->next=head;
	if(head==NULL)
	{
		tp->prev=NULL;
		tp->next=NULL;
		head=tp;
		return;
	}
	head->prev=tp;
	tp->prev=NULL;
	head=tp;
	printf("\nYour data is successfully added into double linked list");
}
void dis()
{
	struct dll *tp;
	if(head==NULL)
	{
		printf("\ndll is empty");
		return;
	}
	tp=head;
	while(tp!=NULL)
	{
		printf("%d==>",tp->data);
		tp=tp->next;
	}
}
int del()
{
	struct dll *tp;
    if(head==NULL)
	{
		printf("\ndll is empty");
		return;
	}
	else
	{
		tp=head;
		head=head->next;
		if(tp->next!=NULL)
		{
			head->prev=NULL;
		}
		k=tp->data;
		free(tp);
		return k;
	}
}
