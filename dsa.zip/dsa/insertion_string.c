#include<stdio.h>
#include<stdlib.h>
void insertion_sort(char [][10],int);
main()
{
	char a[10][10];
	int n,i,j;
	printf("Enter how many strings are there:");
	scanf("%d",&n);
	printf("\nEnter all the strings in a row:\n");
	for(i=0;i<n;i++)
	scanf("%s",&a[i]);
	printf("\nThe strings before sorting:\n");
	for(i=0;i<n;i++)
	printf("%5s",a[i]);
	insertion_sort(a,n);
	printf("\nThe strings after sorting:\n");
	for(i=0;i<n;i++)
	printf("%5s",a[i]);
	return 0;
}
void insertion_sort(char x[10][10],int n)
{
	int i,j,a;
	char t[10];
	for(i=1;i<=(n-1);i++)
	{
		strcpy(t,x[i]);
		for(j=i-1;j>=0 && strcmp(x[j],t)>0;j--)
		{
	    	strcpy(x[j+1],x[j]);
		}
		strcpy(x[j+1],t);
	}
}
