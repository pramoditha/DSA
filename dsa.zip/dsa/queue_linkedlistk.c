#include<stdio.h>
#include<stdlib.h>
struct queue
{
	int data;
	struct queue *next;
};
void create_queue();
void enqueue(int);
int dequeue();
void transversal();
struct queue *front,*rear;
int x;
int main()
{
	int ch,n,k;
	while(ch!=5)
	{
		printf("\n1.Creating queue\n2.Enqueue Operation\n3.Dequeue Operation\n4.Transversal Operation\n5.Exit\nCHOICE:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:create_queue();
			break;
			case 2:printf("Enter a integer:");
			scanf("%d",&n);
			enqueue(n);
			break;
			case 3:k=dequeue();
			printf("Element deletd:%d",k);
			break;
			case 4:transversal();
			break;
			case 5:return -1;
			break;
			default:printf("Eter choice from 1 to 5");
		}
	}
}
void create_queue()
{
	front=NULL;
	rear=NULL;
	printf("Queue created");
}
void enqueue(int x)
{
	struct queue *tp;
	tp=(struct queue *)malloc(sizeof(struct queue));
	if(tp==NULL)
	printf("\nQueue is full");
	else
	{
		tp->data=x;
		tp->next=NULL;
		if(front == NULL && rear == NULL)
		{
			front =tp;
			rear=tp;
		}
		else
		{
			rear->next=tp;
			rear=tp;
		}
	}
}
int dequeue()
{
	struct queue *tp;
	if(front == NULL)
	{
		printf("\nQueue is empty");
	}
	else
	{
		if(front == rear)
		rear=NULL;
		else
		{
			tp=front;
			x=tp->data;
			front=tp->next;
			free(tp);
		}
	}
	return x;
}
void transversal()
{
	struct queue *tp;
	if(front == NULL)
	printf("\nQueue is empty");
	else
	{
		tp=front;
		while(tp!=NULL)
		{
			printf("%4d->",tp->data);
			tp=tp->next;
		}
	}
}
