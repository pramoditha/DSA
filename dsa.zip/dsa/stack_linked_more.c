#include<stdio.h>
#include<stdlib.h>
#define max 20
void push(int);
int pop();
int stk[20],top=-1,k;
int main()
{
	int n,i;
	printf("Enter the number of elements:");
	scanf("%d",&n);
	printf("\nEnter:");
	for(i=0;i<n;i++)
	{
		if(n>20)
		{
			printf("Stack Capacity not supported!!");
			break;
		}
		scanf("%d",&k);
		push(k);
	}
	if(n<=20)
	{
	printf("\nDisplayed in reverse order\n");
	for(i=0;i<n;i++)
	printf("%5d",pop());
}
}
void push(int n)
{
	stk[++top]=n;
}
int pop()
{
	k=stk[top--];
	return k;
}
