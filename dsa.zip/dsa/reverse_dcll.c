#include<stdio.h>
#include<stdlib.h>
struct cdll
{
	int data;
	struct cdll *next;
	struct cdll *prev;
};
struct cdll *last=NULL;
void Addatbegin(int);
void display();
int deleteb();
int main()
{
	int n,x,i,k;
	printf("Enter no.of elements:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&x);
		Addatbegin(x);
	}
	printf("Displaying in order\n");
	display();
	printf("\nDisplaying in reverse order\n");
	for(i=0;i<n;i++)
	printf("%d<==>",deleteb());
}
void Addatbegin(int x)
{
	struct cdll *tp;
	tp=(struct cdll*)malloc(sizeof(struct cdll));
	if(tp==NULL)
	{
		printf("\n Circular dll is full");
		return;
	}
	if(last==NULL)
	{
		tp->data=x;
		tp->next=tp;
		tp->prev=tp;
		last=tp;
	}
	else
	{
		if(last->next==last)
		{
			tp->data=x;
			tp->next=last->next;
			last->next=tp;
			last->next->prev=tp;
			tp->prev=last;
		}
		else
		{
			tp->data=x;
	    	tp->next=last->next;
	    	last->next->prev=tp;
	    	last->next=tp;
	    	tp->prev=last;
		}
	}
}
void display()
{
	struct cdll *tp;
	tp = last->next;
	do
	{
		printf("%4d<===>",tp->data);
		tp=tp->next;
	}while(tp!=last->next);
}
int deleteb()
{
	struct cdll *tp,*pp;
	int x;
	if(last==NULL)
	{
		printf("\n cll is empty!!");
		return;
	}
	if(last==last->next)
	{
		tp=last;
		x=tp->data;
		last=NULL;
	}
	else
	{
		tp=last;
		pp=last->next;
		while(pp->next!=last)
		{
			pp=pp->next;
		}
		pp->next=last->next;
		last->next->prev=pp;
		last=pp;
		x=tp->data;
		free(tp);
	}
	return x;
}
