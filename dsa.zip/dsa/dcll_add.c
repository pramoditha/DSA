#include<stdio.h>
#include<stdlib.h>
struct data_node
{
	int data;
	struct data_node *next;
	struct data_node *prev;
};
struct data_node *last=NULL;
void insertb(int);
void inserts(int,int);
void insertl(int);
void display();

int main()
{

	int x,ch,pos;
	do//char a;
	{//abc:
	printf("\n|-------------------------------------------------|");
	printf("\n|                  MENU:                          |");
	printf("\n|-------------------------------------------------|");
	printf("\n|1.ADDING AN ELEMENT AT BEGINNING                 |");
	printf("\n|2.ADDING AN ELEMENT AT SPECIFIED NODE            |");
	printf("\n|3.ADDING AN ELEMENT AT LAST NODE            |");
	printf("\n|4.DISPLAYING AN ELEMENT FROM THE LINKED LIST     |");
	printf("\n|5.QUIT                                           |");
	printf("\n|-------------------------------------------------|");
	
	
	printf("\n enter your choice from menu:");
	scanf("%d",&ch);
	switch(ch)
	{
	    case 1:
			{
					
				printf("\n enter an integer to be added frist to the circular linked list:");
				scanf("%d",&x);
				insertb(x);
				break;
			}
	
		case 2:
			{
					
				printf("\n enter an integer to be added specified to the linked list:");
				scanf("%d",&x);
				printf("\n enter the position you want to enter");
				scanf("%d",&pos);
				inserts(x,pos);
				break;
			}
			
		case 3:
			{
				printf("\n enter an integer to be added last to the linked list:");
				scanf("%d",&x);
				insertl(x);
				break;
			}
		case 4:
			{
			   if(last==NULL)
				{
					printf("\nlinked list is empty....");
				}
				else
				{ 
				    display();
				}
				break;
			}
		case 5:
			{
				printf("\n program is stopped");
				exit(0);
				break;
			}
		default:printf(" please enter from 1 to 6");
	}
}while(ch!=5);
}
void insertb(int x)
{
	
	struct data_node *tp;
	tp=(struct data_node*)malloc(sizeof(struct data_node));
	if(tp==NULL)
	{
		printf("\nmemory is full or circular linked list is full.you cannot add the elements to circular linked list");
		return;
	}
	if(last==NULL)// empty
	{
	
	    tp->data=x;
    	tp->next=tp;// makes new node to point itself
    	tp->prev=tp;
    	last=tp;
   }
  else
  {
  	if(last->next==NULL)//one node
  	{
  		tp->data=x;
  		tp->next=last;
  		last->next=tp;
  		last->prev=last;
  		tp->prev=last;
  		
	}
	else
	{
  	 tp->data=x;
  	tp->next=last->next;
  	last->next->prev=tp;
  	last->next=tp;
  	tp->prev=last;
  }
  }
	printf("\n your data is added to circular linked list at begin");

}



void inserts(int x,int pos)
{
	struct data_node *tp,*pp;
	tp=(struct data_node*)malloc(sizeof(struct data_node));
//	pp=(struct data_node*)malloc(sizeof(struct data_node));
	int count;
		if(tp==NULL)
	    {
		printf("\nmemory is full or linked list is full.you cannot add the elements to linked list");
		return;
	    }
	    if(pos==1)
	    {
	           	if(last==NULL)// empty
	            {
	
	                 tp->data=x;
                 	tp->next=tp;// makes new node to point itself
                	tp->prev=tp;
    	            last=tp;
                }
                else
              {
           	       if(last->next==last)//one node
            	  {
  	        	    tp->data=x;
  	        	    tp->next=last;
  		            last->next=tp;
  		            last->prev=last;
  	         	    tp->prev=last;
  		
	              }
     	        else
	            {
  	             tp->data=x;
  	            tp->next=last->next;
  	           last->next->prev=tp;
  	           last->next=tp;
  	            tp->prev=last;
               }
             }
       }
	 else
       {
		count=1;
		pp=last->next;
		while(pp->next!=last->next)
		{
			pp=pp->next;
			count++;
		}
		if(pos==count+1)
		{
			tp->data=x;
			tp->next=last->next;
			last->next=tp;
			last->next->prev=tp;
			last=tp;
		}
		else
		{
			count=1;
			pp=last->next;
			while(count<pos-1)
			{
				pp=pp->next;
				count++;
			}
			tp->data=x;
			tp->next=pp->next;
			tp->next->prev=tp;
			tp->prev=pp;
			pp->next=tp;
		}
   }
	
	
	printf("\n your data is successfully added at %d position linked list",pos);

	
}

void insertl(int x)
{
	struct data_node *tp;
	tp=(struct data_node*)malloc(sizeof(struct data_node));
		if(tp==NULL)
	{
		printf("\nmemory is full or linked list is full.you cannot add the elements to linked list");
		return;
	}
	if(last==NULL)
	{
	
	    tp->data=x;
    	tp->next=tp;
    	last=tp;
   }
  else
  {
  	tp->data=x;
  	tp->next=last->next;
  	last->next=tp;
  	last->next->prev=tp;
  	last=tp;
  }
	printf("\n your data is added to linked list at end");


	
}
void display()
{
		struct data_node *tp;
	// dispalying the elements of linked list
	if(last==NULL)
	{
		printf("\n circular linked list is empty!!");
	}
	tp=last->next;// made tp pointer to point 1st node of the linked list
	
	printf("%4d<--->",(tp->data));
	tp=tp->next;
	while(tp!=last->next)
	{
		printf("%4d<---->",(tp->data));
		tp=tp->next;
	}
}
