#include<stdio.h>
#include<stdlib.h>
#define SIZE 20
int harr[SIZE];
int node_cnt=0,n;
void insert(int x);
int Delete();
void heapify(int);
int main()
{
	int x,i,d;
	printf("\n Enter number of nodes in heap:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("\n Enter value %d:",i);
		scanf("%d",&x);
		insert(x);
	}
	printf("\n");
	printf("\n The heap elements are:");
	for(i=0;i<n;i++)
	{
		printf("%4d",harr[i]);
	}
	d=Delete();
    printf("\n %d is deleted",d);
	printf("\n The heap elements after deletion:");
	for(i=0;i<n;i++)
	{
		printf("%4d",harr[i]);
	}
	return 0;
}
void insert(int x)
{
	int i,j,temp;
	if(node_cnt==SIZE-1)
	{
		printf("\n Heap is full");
		return;
	}
	i=node_cnt;
	harr[i]=x;
	node_cnt++;
	j=i;
	while((j!=0)&&(harr[j]>harr[(j-1)/2]))
	{
		temp=harr[j];
		harr[j]=harr[(j-1)/2];
		harr[(j-1)/2]=temp;
		j=(j-1)/2;
	}
	printf("\n Your elements %d is added successfully\n",x);
	for(i=0;i<node_cnt;i++)
	{
		printf("%4d",harr[i]);
	}	
}
int Delete()
{
	int x=harr[0];
	int le=harr[n-1];
	harr[0]=le;
	n=n-1;
	heapify(0);
	return x;
}
void heapify(int i)
{
	int large=i,temp;
	int l=2*i+1;
	int r=2*i+2;
	if(l<n&&harr[l]>harr[large])
	{
		large=l;
	}
	if(r<n&&harr[r]>harr[large])
	{
		large=r;
	}
	if(large!=i)
	{
		temp=harr[i];
		harr[i]=harr[large];
		harr[large]=temp;
		heapify(large);
	}
}
