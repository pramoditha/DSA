#include<stdlib.h>
#include<stdio.h>
struct Data_Node
{
	int data;
	struct Data_Node *next;
};
struct Data_Node * insert(struct Data_Node *, int);
void display(struct Data_Node *);
struct Data_Node * Delete(struct Data_Node *);
struct Data_Node* Delete_last(struct Data_Node *);
struct Data_Node * Delete_node(struct Data_Node *,int );
int main()
{
	struct Data_Node *hp=NULL;
	int ch,x,n,key;
	do
	{
	printf("\n| 1. Adding a linked List                     |");
    printf("\n| 2. Deleting last element from the link list |");
    printf("\n| 3. Deleting first element from the ll       |");
	printf("\n| 4. Delete specified position node           |");
	printf("\n| 5. Displaying a linked List                 |");
	printf("\n| 6. Quit                                     |");
	printf("\n\n Enter your choice from menu:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:printf("\n Enter an integer to be added in a linked list:");
		       scanf("%d",&x);
		       hp=insert(hp,x);
		       break;
		case 2:if(hp == NULL)
	        	{
	        		printf("\n Linked list is empty...!!\n");
         		}
        		else
  	        	{
  	        		x=hp->data;
   	        		hp=Delete(hp);
		        	printf("\n 1st node %d is successfully deleted",x);
	         	}
	         	break;
	    case 3:if(hp == NULL)
	        	{
	        		printf("\n Linked list is empty...!!\n");
         		}
        		else
  	        	{
   	        		hp=Delete_last(hp);
	         	}
	         	break;
	    case 4:
		       printf("\n Enter the position of linked list to delete an element:");
		       scanf("%d",&n);
		       if( hp==NULL)
		       {
		         	printf("\n Linked list is empty, cannot delete");
			   }
			   else
			   {
			     hp=Delete_node(hp,n);
			   }
			   break;
		case 5:if( hp== NULL)
	        	{
	        		printf("\n Linked list is empty");
	        	}
	        	else
	        	{
	        		printf("\n The element in linked list are: \n");
	        		display(hp);
				}
				break;
		case 6:printf("\n This program is stopped now...!!\n");
		       break;
		
		default:printf("\nWrong choice\n");
	            break;
	}
	}while(ch!=6);
}
struct Data_Node * insert(struct Data_Node *hp,int x)
{
	struct Data_Node *tp;
	tp=(struct Data_Node *)malloc(sizeof(struct Data_Node));
	if(tp == NULL)
	{
		printf("\n linked list is full, you cannot add elements");
		return 0;
	}
	tp->data = x;
	tp->next = hp;
	hp=tp;
	printf("\n Your data is successfully added to the linked list\n");
	return hp;
}
struct Data_Node * Delete(struct Data_Node *hp)
{
	struct Data_Node *tp;
	tp=hp;
	hp=hp->next;	
	free(tp);
	return hp;
}
struct Data_Node * Delete_last(struct Data_Node *hp)
{
	int x;
	struct Data_Node *tp,*pp;
	tp=hp;
	while(tp->next!=NULL)
	{
    	tp=tp->next;
	}
	pp=hp;
	while(pp->next!=tp)
	{
		pp=pp->next;
	}
	pp->next=NULL;
	x=tp->data;
	free(tp);
	printf("\n last node %d is deleted successfully from the list",x);
	return(hp);	
}
struct Data_Node* Delete_node(struct Data_Node *hp, int n)
{	
    struct Data_Node *tp,*pp;
    tp=hp;
    int count=1,x;
	while(count<n)
	{
		tp=tp->next;
		count++;
	}
    pp=hp;
	while(pp->next!=tp)
	{
		pp=pp->next;
	}
	pp->next=tp->next;
	x=tp->data;
	printf("\n The element %d from the specified position is deleted",x);
    free(tp);
    return(hp);
}
void display(struct Data_Node *hp)
{
	struct Data_Node *tp;
	tp = hp;
	while( tp!=NULL)
	{
		printf("| %4d |--->",tp->data);
		tp=tp->next;
	}
    printf("NULL");
	printf("\n\n");
}
