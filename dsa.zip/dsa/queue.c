#include<stdio.h>
#include<stdlib.h>
#define capacity 20
void enqueue(int [],int);
int dequeue(int[]);
int frontf(int[]);
int rearf(int[]);
int size();
int isempty(int []);
int isfull(int []);
int countf();
int front=-1,rear=-1,count=0,k1;
int main()
{
	int s[50],x,ch,k;
		char c;
	printf("//////////////////MENU DRIVEN PROGRAM/////////////////////\n");
	printf("1.Enqueue\n2.Dequeue\n3.Front\n4.Rear\n5.isfull\n6.Isempty\n7.count\n8.size\n9.Exit");
	do
	{
	printf("\nEnter choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:printf("Enter integer you wish to add:");
		       scanf("%d",&x);
		       if(isfull(s)==1)
		       printf("Queue is full\n");
		       else
		       enqueue(s,x);
		       break;
		case 2:if(isempty(s)==1)
		       printf("Queue empty\n");
		       else
		       {
		       k=dequeue(s);
		       printf("Element poped from queue is %d\n",k);
		   }
		       break;
		case 3:k=frontf(s);
		       printf("Front=%d\n",k);
		       break;
		case 4:k=rearf(s);
		       printf("Rear=%d\n",k);
		       break;
		case 5:if(isempty(s)==1)
		       printf("queue empty\n");
		       else
		       printf("queue not empty\n");
		       break;
		case 6:if(isfull(s)==1)
		       printf("queue is full\n");
		       else
		       printf("queue has space\n");
		       break;
		case 7:k=countf(s);	
		       printf("Count=%d\n",k);
		       break;
		case 8:k=size(s);	
		       printf("size=%d\n",k);
		       break;
		case 9:return -1;
	}
	printf("Press c to continue:");
	scanf("  %c",&c);
}while(c=='c');
}
int isempty(int s[10])
{
	if(count==0)
	return 1;
	else return 0;
}
int isfull(int s[10])
{
	if(count==capacity)
	return 1;
	else
	return 0;
}
int countf(int s[10])
{
	return count;
}
int size(int s[10])
{
	return capacity;
}
int frontf(int s[10])
{
	if(isempty(s)==1)
	return;
	else
	return s[front];
}
int rearf(int s[10])
{
	if(isempty(s)==1)
	printf("Empty");
	else
	return s[rear];
}
void enqueue(int s[10],int n)
{
	if(isfull(s)==1)
	printf("Is Full");
	else
	{
	if(front==-1)
	{
		front=0;
		s[front]=n;
		rear++;
	}
	else
	{
	rear++;
	s[rear]=n;
}
	count++;
}
}
int dequeue(int s[10])
{
	if(isempty(s)==1)
	printf("Empty");
	else
	{
		k1=s[front];
		front++;
	}
	count--;
	return k1;
}
