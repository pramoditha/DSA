#include<stdio.h>
#include<stdlib.h>
void quick_sort(int [],int,int);
void partion(int [],int,int,int *);
main()
{
	int a[20],n,i,j,lb=0;
	printf("Enter how many intergers are there:");
	scanf("%d",&n);
	printf("\nEnter all the integers in a row:\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("\nThe elements before sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	quick_sort(a,lb,n-1);
	printf("\nThe elements after sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	return 0;
}
void quick_sort(int x[],int lb,int ub)
{
	int j;
	if(lb>=ub)
	return;
	partition(x,lb,ub,&j);
	quick_sort(x,lb,j-1);
	quick_sort(x,j+1,ub);
}
void partition(int x[],int lb,int ub,int *pj)
{
	int up,down,a,t;
	down=lb;
	up=ub;
	a=x[lb];
	while(down<up)
	{
		while(x[down]<=a && down<up)
		{
			down++;
		}
		while(x[up]>a)
		{
			up--;
		}
		if(down<up)
		{
			t=x[down];
			x[down]=x[up];
			x[up]=t;
		}
	}
	x[lb]=x[up];
	x[up]=a;
	*pj=up;
}
