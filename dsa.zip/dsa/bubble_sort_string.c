#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void bubble_sort(char [][10],int);
main()
{
	char a[10][10];
	int n,i,j;
	printf("Enter how many strings are there:");
	scanf("%d",&n);
	printf("\nEnter all the strings in a row:\n");
	for(i=0;i<n;i++)
	scanf("%s",&a[i]);
	printf("\nThe strings before sorting:\n");
	for(i=0;i<n;i++)
	printf("\n%s",a[i]);
	printf("\n");
	bubble_sort(a,n);
	printf("\nThe strings after sorting:\n");
	for(i=0;i<n;i++)
	printf("%5s",a[i]);
	return 0;
}
void bubble_sort(char x[10][10],int n)
{
	int i,j;
	char t[10];
	for(i=0;i<=n-2;i++)
	{
		for(j=0;j<=n-2-i;j++)
		{
			if(strcmp(x[j],x[j+1])>0)
			{
				strcpy(t,x[j]);
				strcpy(x[j],x[j+1]);
				strcpy(x[j+1],t);
			}
		}
	}
}
