#include<stdio.h>
#include<stdlib.h>
#define max 20
void push(int [],int,int *);
int pop(int [],int *);
int topf(int [],int *);
int isempty(int [],int);
int isfull(int [],int);
int count(int [],int);
int size(int [],int);
int i,top=-1,x;
int main()
{
	int s[20],ch,k;
	char c;
	printf("//////////////////MENU DRIVEN PROGRAM/////////////////////\n");
	printf("1.push\n2.pop\n3.top\n4.isempty\n5.isfull\n6.count\n7.size\n8.Exit");
	do
	{
	
	printf("\nEnter choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:printf("Enter integer you wish to add:");
		       scanf("%d",&x);
		       if(isfull(s,top)==1)
		       printf("queue is full\n");
		       else
		       push(s,x,&top);
		       break;
		case 2:if(isempty(s,top)==1)
		       printf("queue empty\n");
		       else
		       {
		       k=pop(s,&top);
		       printf("Element poped from queue is %d\n",k);
		   }
		       break;
		case 3:k=topf(s,&top);
		       printf("Top=%d\n",k);
		       break;
		case 4:if(isempty(s,top)==1)
		       printf("queue empty\n");
		       else
		       printf("queue not empty\n");
		       break;
		case 5:if(isfull(s,top)==1)
		       printf("queue is full\n");
		       else
		       printf("queue has space\n");
		       break;
		case 6:k=count(s,top);	
		       printf("Count=%d\n",k);
		       break;
		case 7:k=size(s,top);	
		       printf("size=%d\n",k);
		       break;
		case 8:return -1;
	}
	printf("Press c to continue:");
	scanf("  %c",&c);
}while(c=='c');
}
void push(int s[20],int x,int *p)
{
	*p=*p+1;
	s[*p]=x;
	printf("Element added\n");
}
int pop(int s[20],int *p)
{
	x=s[*p];
	*p=*p-1;
	return x;
}
int topf(int s[20],int *p)
{
	return s[*p];
}
int isempty(int s[10],int t)
{
	if(t==-1)
	return 1;
}
int isfull(int s[10],int t)
{
	if(t+1==max)
	return 1;
}
int count(int s[10],int t)
{
	return t+1;
}
int size(int s[10],int t)
{
	return max;
}
