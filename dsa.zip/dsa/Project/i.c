#include<stdio.h>
void merge_sort(int [],int,int);
void merge(int [],int,int,int);
int main()
{
	int a[10],n,lb=0,i;
	printf("Enter n value:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("BEFORE SORTING:");
	for(i=0;i<n;i++)
	printf("%4d",a[i]);
	merge_sort(a,lb,n-1);
	printf("\n\nAFTER SORTING:");
	for(i=0;i<n;i++)
	printf("%4d",a[i]);
}
void merge_sort(int a[10],int lb,int ub)
{
	if(lb>=ub)
	return;
    int mid=(lb+ub)/2;
    merge_sort(a,lb,mid);
    merge_sort(a,mid+1,ub);
    merge(a,lb,mid,ub);
}
void merge(int x[10],int lb,int mid,int ub)
{
	int n1,n2,k,i,j;
	n1=mid-lb+1;
	n2=ub-mid;
	int t1[n1],t2[n2];
	for(i=0;i<n1;i++)
	t1[i]=x[lb+i];
	for(j=0;j<n2;j++)
	t2[j]=x[mid+1+j];
	i=0;
	j=0;
	k=lb;
	while(i<n1 && j<n2)
	{
		if(t1[i]<t2[j])
		{
			x[k]=t1[i];
			i++;
		}
		else
		{
			x[k]=t2[j];
			j++;
		}
		k++;
	}
	while(i<n1)
	{
		x[k]=t1[i];
		k++;
		i++;
	}
	while(j<n2)
	{
		x[k]=t2[j];
		k++;
		j++;
	}
}
