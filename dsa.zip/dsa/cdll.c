#include<stdlib.h>
#include<stdio.h>
struct cdll
{
	int data;
	struct cdll *next;
	struct cdll *prev;
}*last=NULL;
void Addatbegin(int);
int Deleteatbegin();
void display();
int main()
{
	int ch,x,r,pos;
	do
	{
	printf("\n|---------------------------------------------|");
	printf("\n|                  MENU                       |");
	printf("\n|---------------------------------------------|");
	printf("\n| 1. Adding a node at the beginning           |");
	printf("\n| 2. deleting a node at the beginning         |");
	printf("\n| 3. Displaying a linked List                 |");	
	printf("\n| 4. exit                                     |");
	printf("\n|---------------------------------------------|");
	printf("\n\n Enter your choice from menu:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:printf("\n Enter an integer to be added in beginnig of circular linked list:");
		       scanf("%d",&x);
		       Addatbegin(x);
		       break;
		case 2:r=Deleteatbegin();
		       printf("\n %d node is deleted from begining successfully",r);
		       break; 
		case 3:if( last== NULL)
	        	{
	        		printf("\nCircular double Linked list is empty");
	        	}
	        	else
	        	{
	        		printf("\n The element in circular linked list are: \n");
	        		display();
				}
				break;
		
		case 4:printf("\n This program is stopped now...!!\n");
		       break;
		
		default:printf("\nWrong choice\n");
	            break;
	}
	}while(ch!=4);
}
void Addatbegin(int x)
{
	struct cdll *tp;
	tp=(struct cdll*)malloc(sizeof(struct cdll));
	if(tp==NULL)
	{
		printf("\n Circular dll is full");
		return;
	}
	if(last==NULL)
	{
		tp->data=x;
		tp->next=tp;
		tp->prev=tp;
		last=tp;
	}
	else
	{
		if(last->next==last)
		{
			tp->data=x;
			tp->next=last->next;
			last->next=tp;
			last->next->prev=tp;
			tp->prev=last;
		}
		else
		{
			tp->data=x;
	    	tp->next=last->next;
	    	last->next->prev=tp;
	    	last->next=tp;
	    	tp->prev=last;
		}
	}
	printf("\n your element is added at the beginning");
}
int Deleteatbegin()
{
	int x;
	struct cdll *tp;
	if(last==NULL)
	{
		printf("\n cdll is empty");
		return 0;
	}
	if(last==last->next)
	{
		tp=last;
		x=tp->data;
		last=NULL;
	}
	else
	{
			tp=last->next;
			last->next=tp->next;
			tp->next->prev=last;
			x=tp->data;
			free(tp);
			return x;
	}
}
void display()
{
	struct cdll *tp;
	tp = last->next;
	do
	{
		printf("%4d<===>",tp->data);
		tp=tp->next;
	}while( tp!=last->next);
}
