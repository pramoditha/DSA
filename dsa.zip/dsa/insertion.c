#include<stdio.h>
#include<stdlib.h>
void insertion_sort(int [],int);
main()
{
	int a[20],n,i,j;
	printf("Enter how many intergers are there:");
	scanf("%d",&n);
	printf("\nEnter all the integers in a row:\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("\nThe elements before sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	insertion_sort(a,n);
	printf("\nThe elements after sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	return 0;
}
void insertion_sort(int x[],int n)
{
	int i,j,t;
	for(i=1;i<=(n-1);i++)
	{
		t=x[i];
		for(j=i-1;j>=0 && x[j]>t;j--)
		{
	    	x[j+1]=x[j];
		}
		x[j=1]=t;
	}
}
