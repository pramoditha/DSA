#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void selection_sort(char [][10],int);
main()
{
	char a[10][10];
	int n,i,j;
	printf("Enter how many strings are there:");
	scanf("%d",&n);
	printf("\nEnter all the strings in a row:\n");
	for(i=0;i<n;i++)
	scanf("%s",&a[i]);
	printf("\nThe strings before sorting:\n");
	for(i=0;i<n;i++)
	printf("%5s",a[i]);
	selection_sort(a,n);
	printf("\nThe strings after sorting:\n");
	for(i=0;i<n;i++)
	printf("%5s",a[i]);
	return 0;
}
void selection_sort(char x[10][10],int n)
{
	int index,i,j;
	char large[10];
	for(i=n-1;i>=1;i--)
	{
		strcpy(large,x[0]);
		index=0;
		for(j=1;j<=i;j++)
		{
			if(strcmp(large,x[j])<0)
			{
				strcpy(large,x[j]);
				index=j;
			}
		}
		strcpy(x[index],x[i]);
		strcpy(x[i],large);
	}
}
