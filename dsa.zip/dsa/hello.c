#include<stdio.h>
void main()
{
	int a,b,sum;
	printf("\nEnter first number:");
	scanf("%d",&a);
	printf("\nEnter second number:");
	scanf("%d",&b);
	sum=a+b;
	printf("Sum=%d",sum);

}
