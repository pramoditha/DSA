#include<stdio.h>
#include<stdlib.h>
struct data_node
{
	int data;
	struct data_node *next;
};
struct data_node* create_sll(struct data_node *,int);
struct data_node* insert(struct data_node *,int);
void display(struct data_node *);
struct data_node* delet(struct data_node *);
int count(struct data_node *);
int isempty(struct data_node *);
int search(struct data_node *,int);
int isfull();
void destroy(struct data_node *);
int main()
{
		struct data_node *hp=NULL;
		int ch,x,k;
		char c;
        do{
        printf("\n|------------------------------------------------------------------------------|");
		printf("\n|                              MENU                                            |");
		printf("\n|------------------------------------------------------------------------------|");
		printf("\n1.create a linked list\n2.Adding an element into the linked list\n3.Displaying the elements of inked list\n4.Deleting an element from linked list\n5.List empty or not\n6.list is full or not\n7.count the no.of elements\n8.Search an element\n9.Destroy Linked list\n10.Quit");
        printf("\nEnter the choice:");
        scanf("%d",&ch);
        	switch(ch)
        	{
        		case 1:printf("\nEnter an integer to create a linked list:");
        		scanf("%d",&x);
				hp=create_sll(hp,x);
				break;
				case 2:printf("\nEnter an integer to add to the linked list:");
        		scanf("%d",&x);
				hp=insert(hp,x);
				break;
				case 3:if(hp==NULL)
				{
					printf("\nLinked List is empty....|||");
				}
				else
				{
					printf("\nThe Elements in the linked list are:\n");
					display(hp);
				}
				break;
				case 4:if(hp==NULL)
				{
					printf("Linked list is empty");
				}
				else
				{
					x=hp->data;
					hp=delet(hp);
				printf("First node is successfully deleted");
			    }
				break;
				case 5:if(isempty(hp))
				{
					printf("\nLinked list is empty");
				}
				else
				{
					printf("Linked list is not empty");
				}
				break;
				case 6:isfull();
			break;
				case 7:if(hp==NULL)
				
				{
					printf("\nLinked list is empty");
				}
				else
				{
					x=count(hp);
					printf("\nThe no.of elements in linked list %d",x);
				}
				break;
				case 8:if(hp==NULL)
	                {
		             printf("\nLinked list is empty you cannot perfoem search");
	                }
	            else{
				printf("Enter the element to be searched:");
				scanf("%d",&x);
				k=search(hp,x);
				if(k!=-1)
				{
					printf("Element found at %d",k);
				}
				else
				{
					printf("Element not present in linked list");
				}
			}
				break;
				case 9:if(hp==NULL)
	                {
		             printf("\nLinked list is empty you cannot perfoem destroy");
	                }
	                else
	                {
	                	destroy(hp);
	                	printf("Drestroyed");
					}
					break;
				case 10:printf("This program is stopped");
				break;
			    default:
				printf("\n you have to select options from 1 to 10 only");	
			}
		}while(ch!=10);
		return 0;
}
struct data_node* create_sll(struct data_node *hp,int x)
{
	struct data_node *tp;
	tp=(struct data_node *)malloc(sizeof(struct data_node));
	if(tp==NULL)
	{
		printf("Linked List is Full");
		return;
	}
	tp->data=x;//adds data to the new node
	tp->next=hp;//makes new node to point address of 1st node in ll
	hp=tp;//hp pointer to point new node
	printf("\nyour data is successfully added to linked list");
	return hp;
}
struct data_node* insert(struct data_node *hp,int x)
{
	struct data_node *tp;
	tp=(struct data_node *)malloc(sizeof(struct data_node));
	if(tp==NULL)
	{
		printf("Linked List is Full");
		return;
	}
	tp->data=x;//adds data to the new node
	tp->next=hp;//makes new node to point address of 1st node in ll
	hp=tp;//hp pointer to point new node
	printf("\nyour data is successfully added to linked list");
	return hp;
}
void display(struct data_node *hp)
{
	struct data_node *tp;
	tp=hp;
	while(tp!=NULL)
	{
		printf("|%d|----->",tp->data);
		tp=tp->next;
	}
	printf("NULL");
	printf("\n\n");
}
struct data_node* delet(struct data_node *hp)
{
	struct data_node *tp;
	tp=hp;//made tp pointer to point 1st node
	hp=hp->next;//made hp pointer to point 2nd node
	free(tp);//deleted the first node
	return hp;//return the second node address
}
int count(struct data_node *hp)
{
	int cnt=0;
	while(hp!=NULL)
	{
		cnt++;
		hp=hp->next;
	}
	return cnt;
}
int isempty(struct data_node *hp)
{
	if(hp=NULL)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int isfull()
{
	struct data_node *tp;
	tp=(struct data_node *)malloc(sizeof(struct data_node));
	if(tp==NULL)
	{
		printf("Linked List Is full");
	}
	else
	{
		printf("Linked list not full");
	}
}
int search(struct data_node *tp,int key)
{
	int p=1;
	while(tp!=NULL)
	{
	if(tp->data==key)
	{
		return p;
	}
	else
	{
	tp=tp->next;
	p++;
}
}
return -1;
}
void destroy(struct data_node *hp)
{
	struct data_node *tp;
	while(hp!=NULL)
	{
	tp=hp;
	hp=hp->next;	
	free(tp);
	}
}
