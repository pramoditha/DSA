#include<stdlib.h>
#include<stdio.h>
/Operations on single ll/
/Defining a structure/
struct cdll
{
	int data;
	struct cdll *next;
	struct cdll *prev;
}*last=NULL;
void Addatbegin(int);
int Deleteatbegin();
void Addatend(int);
/*void Addatmiddle(int,int);*/
void display();

int main()
{
	
	int ch,x,r,pos;
	do
	{
	
	printf("\n|---------------------------------------------|");
	printf("\n|                  MENU                       |");
	printf("\n|---------------------------------------------|");
	printf("\n| 1. Adding a node at the beginning           |");
	printf("\n| 2. deleting a node at the beginning         |");
  //  printf("\n| 3. Adding a node at the end                 |");
    //printf("\n| 3. Adding a node at the specified position  |");*/
	printf("\n| 3. Displaying a linked List                 |");	
	printf("\n| 4. exit                                     |");
	printf("\n|---------------------------------------------|");
	printf("\n\n Enter your choice from menu:");
	scanf("%d",&ch);
	
	switch(ch)
	{
		case 1:printf("\n Enter an integer to be added in beginnig of circular linked list:");
		       scanf("%d",&x);
		       Addatbegin(x);
		       break;
	/*	case 3:printf("\n Enter an integer to be added at the end of circular linked list:");
		       scanf("%d",&x);
		       Addatend(x);
		       break;
	/*	case 3:printf("\n Enter position to add element in circular linked list:");
		       scanf("%d",&pos);
		       printf("\n Enter an integer to be added in the middle of circular linked list:");
		       scanf("%d",&x);
		       
		       Addatmiddle(x,pos);
		       break;*/
		case 2:
		       r=Deleteatbegin();
		       printf("\n %d node is deleted from begining successfully",r);
		       break; 
		case 3:if( last== NULL)
	        	{
	        		printf("\nCircular double Linked list is empty");
	        	}
	        	else
	        	{
	        		printf("\n The element in circular linked list are: \n");
	        		display();
				}
				break;
		
		case 4:printf("\n This program is stopped now...!!\n");
		       break;
		
		default:printf("\nWrong choice\n");
	            break;
	}
	}while(ch!=4);
}

void Addatbegin(int x)
{
	struct cdll *tp;
	tp=(struct cdll*)malloc(sizeof(struct cdll));
	if(tp==NULL)
	{
		printf("\n Circular dll is full");
		return;
	}
	if(last==NULL)
	{
		tp->data=x;
		tp->next=tp;
		tp->prev=tp;
		last=tp;
	}
	else
	{
		if(last->next==last)
		{
			tp->data=x;
			tp->next=last->next;
			last->next=tp;
			last->next->prev=tp;
			tp->prev=last;
		}
		else
		{
			tp->data=x;
	    	tp->next=last->next;
	    	last->next->prev=tp;
	    	last->next=tp;
	    	tp->prev=last;
		}
		
	}
	printf("\n your element is added at the beginning");
}


/*void Addatend(int x)
{
	struct cdll *tp;
	tp=(struct cdll*)malloc(sizeof(struct cdll));
	if(tp==NULL)
	{
		printf("\n Circular ll is full");
		return;
	}
	if(last==NULL)
	{
    	tp->data=x;
		tp->next=tp;
		tp->prev=tp;
		last=tp;
	}
	else
	{
	
    	if(last->next==last)
   		{
			tp->data=x;
			last->next=tp;
			tp->next=last;
			tp->prev=last;
	    	tp->next->prev=tp;
			
		}
		else
		{
			tp->data=x;
	    	tp->next=last->next;
	    	last->next->prev=tp;
	    	last->next=tp;
	    	tp->prev=last;
		}
		
	}
	printf("\n your element is added at the end");
}
/*void Addatmiddle(int x,int pos)
{
	struct cdll *tp,*pp;
	int count;
	tp=(struct cdll*)malloc(sizeof(struct cdll));
	if(tp==NULL)
	{
		printf("\n Circular ll is full");
		return;
	}
	if(pos==1)
	{
		tp->data=x;
		tp->next=last->next;
		last->next=tp;   	
	}
	else
	{
		count=1;
		pp=last->next;
		while(pp->next!=last->next)
		{
	    	pp=pp->next;
	    	count++;
		}
		if(pos==count+1)
		{
			tp->data=x;
    		tp->next=last->next;
	    	last->next=tp; 
	    	last=tp;
		}
		else
		{
			count=1;
			pp=last->next;
			while(count<pos-1)
			{
				pp=pp->next;
				count++;
			}
			tp->data=x;
			tp->next=pp->next;
			pp->next=tp;
		}
	}
	
}*/
int Deleteatbegin()
{
	int x;
	struct cdll *tp;
	if(last==NULL)
	{
		printf("\n cdll is empty");
		return 0;
	}
	if(last==last->next)
	{
		tp=last;
		x=tp->data;
		last=NULL;
	}
	else
	{
	
			tp=last->next;
			last->next=tp->next;
			tp->next->prev=last;
			x=tp->data;
			free(tp);
			return x;
	}
}
void display()
{
	struct cdll *tp;
	
	//displaying the elements of ll
	tp = last->next;//made to pointer to point 1st node of ll
	
	do
	{
		printf("%4d<===>",tp->data);
		tp=tp->next;
	}while( tp!=last->next);

}
