#include<stdio.h>
#include<stdlib.h>
struct tnode
{
	int data;
	struct tnode *left;
	struct tnode *right;
};
struct tnode *root = NULL;
int search();
void insert();
void inorder(struct tnode *);
void preorder(struct tnode *);
void postorder(struct tnode *);
void del();
void main()
{
	int ch,k,n;
	do
	{
		printf("\n|-------------------------------|");
		printf("\n|             MENU              |");
		printf("\n|-------------------------------|");
		printf("\n|    1.INSERT                   |");
	    printf("\n|    2.INORDER TRAVERSE         |");
	    printf("\n|    3.PREORDER TRAVERSE        |");
	    printf("\n|    4.POSTORDER TRAVERSE       |");
	    printf("\n|    5.Binary Search            |");
	    printf("\n|    6.Deleting                 |");
	    printf("\n|    7.EXIT                     |");
	    printf("\n|-------------------------------|");
		printf("\n Enter your choice: ");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				insert();
				break;
			case 2:
				if(root==NULL)
				{
					printf("\n Tree Is Empty");
				}
				else
				{
				inorder(root);
			    }
				break;
			case 3:
				if(root == NULL)
				{
					printf("\n Tree Is Empty");
				}
				else
				{
					preorder(root);
				}
				break;
			case 4:
				if(root == NULL)
				{
					printf("\n Tree Is Empty");
				}
				else
				{
					postorder(root);
				}
				break;
			case 5:k=search();
			if(k==0)
			printf("Not Found");
			else
			printf("FOUND!!!");
			break;
			case 6:printf("Enter the node to be deleted");
			scanf("%d",&k);
			del(k);
			break;
			case 7:
				printf("\n Program is stopped");
				break;
			default:
				printf("\n Invalid Choice");
				break;
		}
	}while(ch!=7);
}
void insert()
{
	struct tnode *tp,*lp,*lpp;
	int x;
	tp = (struct tnode *)malloc(sizeof(struct tnode));
	if(tp==NULL)
	{
		printf("\n memory is not allocated");
		
	}
	else
	{
		printf("\n Enter Data:");
		scanf("%d",&x);
		tp->data=x;
		tp->left=NULL;
		tp->right=NULL;
		if(root == NULL)
		{
			root = tp;
		}
		else
		{
			lp=root;
			while(lp!=NULL)
			{
				lpp=lp;
				if(x<lp->data)
				{
					lp=lp->left;
				}
				else if(x>lp->data)
				{
					lp=lp->right;
				}
				else
				{
					printf("\n Duplicate Elements cannot be Inserted");
					break;
				}
			}
			if(lp==NULL)
			{
				if(x<lpp->data)
				{
					lpp->left=tp;
				}
				else
				{
					lpp->right=tp;
				}
			}
		}
	}
	printf("\n Data is inserted");
}
void inorder(struct tnode *tp)
{
 if(tp!=NULL)
 {
 	inorder(tp->left);
 	printf("%d\t",tp->data);//ROOT
 	inorder(tp->right);
 	//printf("%d\t",temp->info);
	 }	
}
void preorder(struct tnode *tp)
{
	if(tp!=NULL)
	{
		printf("%d\t",tp->data);
		preorder(tp->left);
		preorder(tp->right);
	}
}
void postorder(struct tnode *tp)
{
	if(tp!=NULL)
	{
		postorder(tp->left);
		postorder(tp->right);
		printf("%d\t",tp->data);
	}
}
int search()
{
	int key;
	printf("Enter Key value:");
	scanf("%d",&key);
	struct tnode *tp;
	tp=root;
	while(tp!=NULL)
	{
		if(key==tp->data)
		return 1;
		else if(key<tp->data)
		tp=tp->left;
		else
		tp=tp->right;
	}
	if(tp!=NULL)
	return 1;
	else
	return 0;
}
void del(int x)
{
	struct tnode *pp,*tp;
	if(root==NULL)
	{
		printf("\nTree is Empty");
		return;
	}
	/*Searching*/
	pp=NULL;
	tp=root;
	while(tp->data!=x && tp!=NULL)
	{
		pp=tp;
		if(tp->data<x)
		{
			tp=tp->right;
		}
		else
		{
			tp=tp->left;
		}
	}
	if(tp==NULL)
	{
		printf("Given value is not found in tree");
		return;
	}
	/*deleting the node*/
	if(tp==pp->left)
	{
		pp->left=NULL;
	}
	else
	{
		pp->right=NULL;
	}
	printf("Node is deleted");
	free(tp);
}
