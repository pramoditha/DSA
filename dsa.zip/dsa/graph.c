#include<stdio.h>
#include<stdlib.h>
int a[20][20];
void adde();
int addn(int );
void dele();
int deln(int );
void display(int );
int main()
{
	int i,j,n,ch;
	printf("\n enter no:of nodes:");
	scanf("%d",&n);
	printf("\n enter matrix:");
    for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		printf("\n enter element[%d][%d]:",i,j);
    		scanf("%d",&a[i][j]);
		}
	}
	printf("\n display\n");
	for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		printf("\t %d",a[i][j]);
		}
		printf("\n");
	}
	
	do
	{
		printf("\n|------------------------------|");
		printf("\n|            MENU              |");
		printf("\n|------------------------------|");
		printf("\n|1.ADDING AN EDGE              |");
		printf("\n|2.ADDING A NODE               |");
		printf("\n|3.DELETING AN EDGE            |");
		printf("\n|4.DELETING A NODE             |");
		printf("\n|5.DISPLAYING ADJACENCY MATRIX |");
		printf("\n|6.EXIT                        |");
		printf("\n|------------------------------|");
		printf("\n enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:
				{
					adde();
					printf("\n edge is added");
					break;
				}
			case 2:
				{
					n=addn(n);
					printf("\n node is added");
					break;
				}
			case 3:
				{
					dele();
					printf("\n edge is deleted");
		            break;
				}
			case 4:
				{
					n=deln(n);
					printf("\n node is deleted");
		            break;
					
				}
			case 5:
			    {
			    	display(n);
			    	break;
				}
			case 6:
				{
					exit(0);
				}	
		}
	}while(ch!=6);
}
void adde()
{
	int x,y;
	
	printf("\n enter node in row:");
	scanf("%d",&x);
	
	printf("\n enter node in coloumn:");
	scanf("%d",&y);
	
    a[x][y]=1;
}
int addn(int n)
{
	int x,i,j;
	n=n+1;
	
	for(i=0;i<n-1;i++)
    {
    	printf("\n enter element[%d][%d]:",i,n-1);
    		scanf("%d",&a[i][n-1]);
	}

	
	for(i=n-1;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		printf("\n enter element[%d][%d]:",i,j);
    		scanf("%d",&a[i][j]);
		}
	}
	return(n);
}
void dele()
{
	int x,y;
	
	printf("\n enter  node in row:");
	scanf("%d",&x);
	
	printf("\n enter node in coloumn:");
	scanf("%d",&y);
	
    a[x][y]=0;
    a[y][x]=0;
}
int deln(int n)
{
	n=n-1;
	return(n);
}
void display(int n)
{
	int i,j;
	for(i=0;i<n;i++)
    {
    	for(j=0;j<n;j++)
    	{
    		printf("\t %d",a[i][j]);
		}
		printf("\n");
	}	
}
