#include<stdio.h>
#include<stdlib.h>
struct tnode 
{
	int data;
	struct tnode *left;
	struct tnode *right;
};
struct tnode *root=NULL;
struct tnode * insert(struct tnode *,int x);
void inorder(struct tnode *);
void preorder(struct tnode *);
void postorder(struct tnode *);
int main()
{
	int i,n,x,key,r,ch;
	do
	{
	printf("\n|-------------------------------------------------|");
	printf("\n|                  MENU:                          |");
	printf("\n|-------------------------------------------------|");
	printf("\n|1.ADDING AN ELEMENT TO TREE                      |");
	printf("\n|2.DISPLAY IN INOREDER                            |");
	printf("\n|3.DISPLAY IN PRE ORDER                           |");
	printf("\n|4.DISPLAY IN POST ORDER                          |");
	printf("\n|5.QUIT                                           |");
	printf("\n|-------------------------------------------------|");
	printf("\n enter your choice from menu:");
	scanf("%d",&ch);
	switch(ch)
	{
	    case 1:
			{
					
				printf("\n enter an integer to be added :");
				scanf("%d",&x);
				root=insert(root,x);
				printf("\n your node is added to tree");
				break;
			}
		case 2:
			{
				inorder(root);
				break;
			}
		case 3:
			{
				preorder(root);
				break;
			}
		case 4:
			{
				postorder(root);
				break;
			}
		case 5:
	    	{
	    		printf("\n program is stopped");
				exit(0);
				break;
	    	}
		default:
			{
		   		printf(" please enter from 1 to 8");
		   	}
	}
  }while(ch!=5);
}

//c-code to insert the nodes of a tree  
struct tnode * insert(struct tnode *root,int x)
{
    if(root==NULL)
    {
        root=(struct tnode *)malloc(sizeof(struct tnode));
        root->left=NULL;
		root->right=NULL;
        root->data=x;
    }
    else
    {
        if(x<root->data)
        {
            root->left=insert(root->left,x);
        }
        else//(x>root->data)
        {
            root->right=insert(root->right,x);
        }
    }
    return(root);
}

//c-code to display the nodes of a tree in inorder
void inorder(struct tnode *tp)
{
	if(tp!=NULL)
	{
		inorder(tp->left);
	    printf("%4d",tp->data);
	    inorder(tp->right);
	}
}

//c-code to display the nodes of a tree in preorder
void preorder(struct tnode *tp)
{
	if(tp!=NULL)
	{
	    printf("%4d",tp->data);
	    preorder(tp->left);
	    preorder(tp->right);
	} 
}

//c-code to display the nodes of a tree in postorder
void postorder(struct tnode *tp)
{
	if(tp!=NULL)
	{
	
	    postorder(tp->left);
	    postorder(tp->right);
	     printf("%4d",tp->data);
	}
}

