#include<stdio.h>
struct student
{
	int ht;
	char name[10];
	int sub[6];
	int t;
	float p;
}s[10],t;
void bubble_sort(struct student [],int);
main()
{
	int i,n,j;
	printf("Enter no.of students:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter Student-%d",i+1);
		printf("\nEnter hall-ticket Number:");
		scanf("%d",&s[i].ht);
		printf("Enter Name:");
		scanf("%s",s[i].name);
		printf("Enter marks in order\n");
		for(j=0;j<6;j++)
		scanf("%d",&s[i].sub[j]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<6;j++)
		s[i].t=s[i].t+s[i].sub[j];
		s[i].p=(float)s[i].t/(float)6;
}
bubble_sort(s,n);
printf("-----------Student Details-----------\n");
printf("H-T Num\tName\tsm1\tsm2\tsm3\tsm4\tsm5\tsm6\tTotal\tPercentage\n");
	for(i=n-1;i>=0;i--)
	{
		printf("%d\t%s  ",s[i].ht,s[i].name);
		for(j=0;j<6;j++)
		printf("\t%d",s[i].sub[j]);
	    printf("\t%d\t%5f\n",s[i].t,s[i].p);
	}
}
void bubble_sort(struct student s[10],int n)
{
	int i,j;
	for(i=0;i<=n-2;i++)
	{
		for(j=0;j<=n-2-i;j++)
		{
			if(s[i].t>s[i+1].t)
			{
				t=s[i];
				s[i]=s[i+1];
				s[i+1]=t;
			}
		}
	}
}
