#include<stdio.h>
#include<stdlib.h>
struct cll
{
	int data;
	struct cll * next;
	struct cll* last;
}*last=NULL;
struct cll * AddAtStart(int);
struct cll *AddAtEnd(int);
struct cll * AddAtMiddle(int,int);
int count=0;
void display();
int main()
{
	int ch,x,pos;
	do
	{
		printf("\n|----------------------------------------------------------------|");
		printf("\n|                     MENU                                       |");
		printf("\n|----------------------------------------------------------------|");
		printf("\n|1.Adding an element at Beginning                                |");
		printf("\n|2.Adding an element at End                                      |");
		printf("\n|3.Adding an element at Specified Position                       |");
		printf("\n|4.Display                                                       |");
		printf("\n|                    Exit                                        |");
    	printf("\n|----------------------------------------------------------------|");
    	printf("\nEnter choice:");
    	scanf("%d",&ch);
    	switch(ch)
    	{
    		case 1:printf("\nEnter a number to add to the linked list at the beginning:");
    		scanf("%d",&x);
    		AddAtStart(x);
    		break;
    		case 2:printf("\nEnter a number to add to the linked list at the end:");
    		scanf("%d",&x);
    		AddAtEnd(x);
    		break;
    		case 3:printf("\nEnter a number to add to the linked list at the specified place:");
    		scanf("%d",&x);
    		printf("\nEnter position:");
    		scanf("%d",&pos);
    		AddAtMiddle(x,pos);
    		break;
    		case 4:display();
    		break;
    		case 5:printf("\nYour program is stopped");
    		return -1;
		}
	}while(ch!=5);
}
struct cll * AddAtStart(int x)
{
	struct cll *tp;
	tp=(struct cll *)malloc(sizeof(struct cll));
	if(tp==NULL)
	{
		printf("\nLinked List is Full");
		return;
	}
	if(last== NULL)
	{
		tp->data=x;
		tp->next=tp;
		last=tp;
	}
	else
	{
		tp->data=x;
		tp->next=last->next;
		last->next=tp;
	}
	printf("Your Element is added at begging\n");
}
struct cll * AddAtEnd(int x)
{
	struct cll *tp;
	tp=(struct cll *)malloc(sizeof(struct cll));
	if(tp==NULL)
	{
		printf("\nLinked List is Full");
		return;
	}
	if(last == NULL)
	{
		tp->data=x;
		tp->next=tp;
		last=tp;
	}
	else
	{
		tp->data=x;
		tp->next=last->next;
		last->next=tp;
		last=tp;
	}
	printf("Your Element is added at end\n");
}
struct cll * AddAtMiddle(int x,int pos)
{
	struct cll *tp,*pp;
	tp=(struct cll *)malloc(sizeof(struct cll));
	if(tp==NULL)
	{
		printf("\nLinked List is Full");
		return;
	}
	if(pos == 1)
	{
		tp->data=x;
		tp->next=last->next;
		last->next=tp;
	}
	else
	{
		count=1;
		pp=last->next;
		while(pp->next!=last->next)
		{
			pp=pp->next;
			count++;
	}
			if(pos==count+1)
			{
				tp->data=x;
				tp->next=last->next;
				last->next=tp;
				last=tp;
			}
			else
			{
				count=1;
				pp=last->next;
				while(count<pos-1)
				{
					pp=pp->next;
					count++;
				}
				tp->data=x;
				tp->next=pp->next;
				pp->next=tp;
			}
	}
	printf("Your Element is added\n");
}
void display()
{
	struct cll *tp;
	if(last == NULL)
	{
		printf("\nCLL is empty");
		return;
	}
	tp=last->next;
	do
	{
		printf("%4d---->",tp->data);
		tp=tp->next;
	}while(tp!=last->next);
}
