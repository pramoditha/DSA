#include<stdio.h>
#include<stdlib.h>
void bubble_sort(int [],int);
main()
{
	int a[20],n,i,j;
	printf("Enter how many intergers are there:");
	scanf("%d",&n);
	printf("\nEnter all the integers in a row:\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("\nThe elements before sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	bubble_sort(a,n);
	printf("\nThe elements after sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	return 0;
}
void bubble_sort(int x[],int n)
{
	int t,i,j,flag;
	for(i=0;i<=n-2;i++)
	{
		flag=0;
		for(j=0;j<=n-2-i;j++)
		{
			if(x[j]>x[j+1])
			{
				t=x[j];
				x[j]=x[j+1];
				x[j+1]=t;
				flag=1;
			}
		}
		if(flag==0)
		{
			printf("\nThe elements are found that they are in sorted order after %d pass\n",i+1);
			return;
		}
	}
}
