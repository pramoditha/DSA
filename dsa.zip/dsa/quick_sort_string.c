#include<stdio.h>
#include<stdlib.h>
void quick_sort(char [][10],int,int);
void partion(char [][10],int,int,int *);
main()
{
	char a[10][10];
	int n,i,j,lb=0;
	printf("Enter how many strings are there:");
	scanf("%d",&n);
	printf("\nEnter all the strings in a row:\n");
	for(i=0;i<n;i++)
	scanf("%s",&a[i]);
	printf("\nThe strings before sorting:\n");
	for(i=0;i<n;i++)
	printf("%5s",a[i]);
	quick_sort(a,lb,n-1);
	printf("\nThe strings after sorting:\n");
	for(i=0;i<n;i++)
	printf("%5s",a[i]);
	return 0;
}
void quick_sort(char x[10][10],int lb,int ub)
{
	int j;
	if(lb>=ub)
	return;
	partition(x,lb,ub,&j);
	quick_sort(x,lb,j-1);
	quick_sort(x,j+1,ub);
}
void partition(char x[10][10],int lb,int ub,int *pj)
{
	int up,down;
	char t[10],a[10];
	down=lb;
	up=ub;
	strcpy(a,x[lb]);
	while(down<up)
	{
		while(strcmp(x[down],a)<=0 && down<up)
		{
			down++;
		}
		while(strcmp(x[up],a)>0)
		{
			up--;
		}
		if(down<up)
		{
		    strcpy(t,x[down]);
			strcpy(x[down],x[up]);
			strcpy(x[up],t);
		}
	}
	strcpy(x[lb],x[up]);
	strcpy(x[up],a);
	*pj=up;
}
