#include<stdio.h>
#include<stdlib.h>
void ins_record();
void ins_record_beggining();
void ins_record_end();
void ins_record_specified();
void deleterecord();
void deleteatbegin();
void deleteatend();
void deleteatspecified();
void create_new();
void display();
void countrecord();
void searchrecord();
void updaterecord();
struct node
{
	int roll,class;
	char name[30],firstname[30];
	float total_marks,percentage;
	struct node *next;
};
struct node *start=NULL;
main()
{
	int ch;
	printf("1.create new student record \n2.insert student details\n3.search a student record\n4.count total students\n5.delete student record\n6.To show all records\n7.To update particular student details.\n8.exit\n");
	while(1)
	{
		printf("\nenter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:create_new();
			        break;
			case 2:ins_record();
			        break;
			case 3:searchrecord();
			       break;
			case 4:countrecord();
			       break;
			case 5:deleterecord();
			       break;
			case 6:display();
			       break;
			case 7:updaterecord();
			       break;
			case 8:exit(0);
			default:printf("\n invalid choice");
		}
	}
}
void ins_record()
{
	int ch;
	printf("To insert a student record at \n1.Begin\n2.End\n 3.Specified\n");
	{
		printf("enter your choice:");
	    scanf("%d",&ch);
		switch(ch)
		{
			case 1:ins_record_beggining();
			       break;
			case 2:ins_record_end();
			       break;
			case 3:ins_record_specified();
			       break;
			default:printf("\n invalid choice");
			
		}	
	} 
}
void updaterecord()
{
	struct node *temp,*ptr;
	int loc,count=1;
	if(start==NULL)
	{
		printf("\nstudent details are not entered\n");
	}
	else
	{
	    printf("enter the roll of student  to be updated:");
		scanf("%d",&loc);
		temp=start;
		count=1;
		while(temp!=NULL && temp->roll!=loc)
		{
			ptr=temp;
			count=count+1;
			temp=temp->next;
		}
			if(temp==NULL)
			{
				printf("\nparticular student don't belongs to our school\n");
			}
			else
			{
				ptr->next=temp->next;
				int ch;
				printf("\nTo update press 1.first name\n2.last name\n3.roll-no\n4.class\n5.total marks\n6.percentagecentage\n");
				printf("enter the user choice:");
				scanf("%d",&ch);
				switch(ch)
				{
					case 1:printf("\nenter the new first name\n");
						   scanf("%s",temp->firstname);
						   break;
					case 2:printf("enter the new last name\n");
					       scanf("%s",temp->name);
					       break;
				    case 3:printf("enter the new roll\n");
				           scanf("%d",&temp->roll);
				           break;
				    case 4:printf("enter the new class\n");
				           scanf("%d",&temp->class);
				           break;
				    case 5:printf("enter the new total marks\n");
				           scanf("%f",&temp->total_marks);
				           break;
				    case 6:printf("enter the new percentagecentage\n");
				           scanf("%f",&temp->percentage);
				           break;
				    case 7:exit(0);
				    default:printf("invalid choice\n");
				}
			}
		}
	}
void display()
{
	struct node *temp;
	if(start==NULL)
	{
		printf("\n list is empty");
	}
	else
	{
		temp=start;
		printf("\nstudent details  are\n");
		int i=0;
		while(temp!=NULL)
		{
			i++;
			printf("\n\nStudent-%d",i);
			printf("\nRoll.NO:%d\nFirst Name:%s\nFirst Name:%s\nClass:%d\nTotal Marks:%f\npercentage:%f\n", temp->roll,temp->firstname,temp->name,temp->class, temp->total_marks,((temp->percentage)/600)*100);
			temp=temp->next;
		}
	}
}
void countrecord()
{
	struct node *newnode,*temp,*ptr;
	int count=0;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(start==NULL)
	{
		printf("\nstudent details are not entered\n");
	}
	else
	{
		temp=start;
		while(temp!=NULL)
		{
			count++;
			temp=temp->next;
		}
		if(count==0)
		{
			printf("\nstudent have not yet joined\n");
		}
		else
		{
			printf("\nNumber of student :%d\n",count);
		}
	}
}
void searchrecord()
{
	struct node *temp,*ptr;
	int loc,count=1;
	if(start==NULL)
	{
		printf("\nstudent details are not entered\n");
	}
	else
	{
		
		printf("\nenter the roll no of student");
		scanf("%d",&loc);
		temp=start;
		count=1;
		while(temp!=NULL && temp->roll!=loc)
		{
			ptr=temp;
			count=count+1;
			temp=temp->next;
		}
			if(temp==NULL)
			{
				printf("\nparticular student don't belongs to our school\n");
			}
			else
			{
			ptr->next=temp->next;
			printf("\n\nRoll.NO:%d\nFirst Name:%s\nFirst Name:%s\nClass:%d\nTotal Marks:%f\npercentagecentage:%f\n", temp->roll,temp->firstname,temp->name,temp->class, temp->total_marks,((temp->percentage)/600)*100);
				return;
			}
		
	}
}
void ins_record_beggining()
{
	struct node *newnode;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(newnode==NULL)
	{
		printf("\n memory is not allocated\n");
	}
	else
	{
	     int m1,m2,m3,m4,m5,m6,r,a;
	     printf("\n\n***enter student to be inserted details***\n\n");
	      printf("roll:");
	       	    scanf("%d",&r);
	       	    printf("First Name:");
	       	    scanf("%s",newnode->firstname);
	       	    printf("Last Name:");
	       	    scanf("%s",newnode->name);
	       	    printf("Class:");
	       	    scanf("%d",&newnode->class);
	       	    printf("Marks in Order:");
	       	    scanf("%d%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5,&m6);
			    newnode->roll=r;
			    newnode->class=a;
			    newnode->total_marks=(m1+m2+m3+m4+m5+m6);	
		        newnode->percentage=((newnode->total_marks)/100)*100;
		        newnode->next=NULL;
		  	    if(start==NULL)
		     {
		     	start=newnode;
			 }
			 else
			 {			 	 
				 newnode->next=start;
				 start=newnode;
			 } 
    }
}
void create_new()
{
	int total,i;
	struct node *temp,*newnode;
	
	    printf("enter the number of record you want to create:");
	    scanf("%d",&total);
	    printf("\n\n***enter student details***\n\n");
	    if(total<=0)
	    {
		printf("list must be greater than zero");
	    }
	    else
	    {
	    	int a,r,m1,m2,m3,m4,m5,m6;
	     temp=(struct node*)malloc(sizeof(struct node));
	              printf("roll:");
	       	    scanf("%d",&r);
	       	    printf("First Name:");
	       	    scanf("%s",temp->firstname);
	       	    printf("Last Name:");
	       	    scanf("%s",temp->name);
	       	    printf("Class:");
	       	    scanf("%d",&a);
	       	    printf("Marks in Order:");
	       	    scanf("%d%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5,&m6);
			     temp->roll=r;
			     temp->class=a;
			     temp->total_marks=(m1+m2+m3+m4+m5+m6);	
		         temp->percentage=((temp->total_marks)/100)*100;
		         temp->next=NULL;
		     start=temp;  
		     for(i=2;i<=total;i++)
		     {
		     	newnode=(struct node*)malloc(sizeof(struct node));
		     	int r,a,m1,m2,m3,m4,m5,m6;
	             printf("roll:");
	       	    scanf("%d",&r);
	       	    printf("First Name:");
	       	    scanf("%s",newnode->firstname);
	       	    printf("Last Name:");
	       	    scanf("%s",newnode->name);
	       	    printf("Class:");
	       	    scanf("%d",&newnode->class);
	       	    printf("Marks in Order:");
	       	    scanf("%d%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5,&m6);
			     newnode->roll=r;
			     newnode->class=a;
			     newnode->total_marks=(m1+m2+m3+m4+m5+m6);	
		         newnode->percentage=((newnode->total_marks)/100)*100;
		         newnode->next=NULL;
		         temp->next=newnode;
		         temp=newnode;
			 }
		      
	       }
        }
void ins_record_end()
{
  struct node *newnode,*temp;
  newnode=(struct node*)malloc(sizeof(struct node));
  if(newnode==NULL)
  {
  	printf("\nmemory is not allocated");
  }	
  else
  {
  	printf("\nroll\tfirst name\tname\tclass\total_marksarks in six subjects");
		     	int r,m1,m2,m3,m4,m5,m6;
	       	    float m;
	       	    printf("roll:");
	       	    scanf("%d",&r);
	       	    printf("First Name:");
	       	    scanf("%s",newnode->firstname);
	       	    printf("Last Name:");
	       	    scanf("%s",newnode->name);
	       	    printf("Class:");
	       	    scanf("%d",&newnode->class);
	       	    printf("Marks in Order:");
	       	    scanf("%d%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5,&m6);
			     newnode->roll=r;
			     newnode->total_marks=(m1+m2+m3+m4+m5+m6);	
		         newnode->percentage=((newnode->total_marks)/100)*100;
		         newnode->next=NULL;
		         if(start==NULL)
		         {
		         	start=newnode;
				 }
				 else
				 {
				 	temp=start;
				 	while(temp->next!=NULL)
				 	{
				 		temp=temp->next;
					 }
					 temp->next=newnode;
					 }
  }
}   
void ins_record_specified()
{
    struct node *newnode,*temp,*ptr;
	int item,loc,count=1,m1,m2,m3,m4,m5,m6;
	newnode=(struct node*)malloc(sizeof(struct node));
	if(newnode==NULL)
	{
		printf("\nmemory is not allocated");
	}
	else
	{
		     	int r;
	             printf("roll:");
	       	    scanf("%d",&r);
	       	    printf("First Name:");
	       	    scanf("%s",newnode->firstname);
	       	    printf("Last Name:");
	       	    scanf("%s",newnode->name);
	       	    printf("Class:");
	       	    scanf("%d",&newnode->class);
	       	    printf("Marks in Order:");
	       	    scanf("%d%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5,&m6);
			     newnode->roll=r;
			     newnode->total_marks=(m1+m2+m3+m4+m5+m6);	
		         newnode->percentage=((newnode->total_marks)/100)*100;
		         newnode->next=NULL;
	if(start==NULL)
	{
		start=newnode;
	}
	else
	{
		printf("\n enter position at which you want to insert particular student");
		scanf("%d",&loc);
		temp=start;
		while(temp!=NULL && count!=loc)
		{
			count++;
			ptr=temp;
			temp=temp->next;
		}
		if(temp==NULL)
		{
			printf("\nplease enter the correct position");
		}
		else
		{
			ptr->next=newnode;
			newnode->next=temp;
		}
	}
}
}
void deleterecord()
{
	int ch;
	printf("\nTo delete a student record at\n 1.begin\n2.end\n 3. specified\n");
	{
		printf("enter your choice");
	    scanf("%d",&ch);
		switch(ch)
		{
			case 1:deleteatbegin();
			       break;
			case 2:deleteatend();
			       break;
			case 3:deleteatspecified();
			       break;
			default:printf("\n invalid choice");
			
		}	
	}
}
void deleteatbegin()
{
	struct node *temp;
	if(start==NULL)
	{
		printf("\n student details are not entered");
	}
	else
	{
		temp=start;
		printf("\nDeleted student\n");
		printf("\n\nRoll.NO:%d\nFirst Name:%s\nFirst Name:%s\nClass:%d\nTotal Marks:%f\npercentagecentage:%f\n", temp->roll,temp->firstname,temp->name,temp->class, temp->total_marks,((temp->percentage)/600)*100);
		start=start->next;
		free(temp);
		return;
	}
}
void deleteatend()
{
	struct node *temp;
	struct node *ptr;
	
	if(start==NULL)
	{
		printf("\nstudent details are not entered\n");
	}
    else
    {
	temp=start;
	if(start->next==NULL)
	{
		start=NULL;
	}
	else
	while(temp->next!=NULL)
	{
		ptr=temp;
		temp=temp->next;
	}
		ptr->next=NULL;
		printf("\ndeleted student details is\n");
		printf("\nDeleted student\n");
		printf("\n\nRoll.NO:%d\nFirst Name:%s\nFirst Name:%s\nClass:%d\nTotal Marks:%f\npercentagecentage:%f\n", temp->roll,temp->firstname,temp->name,temp->class, temp->total_marks,((temp->percentage)/600)*100);
		free(temp);
        return;
	
}
}
void deleteatspecified()
{
	struct node *temp,*ptr;
	int loc,count=1;
	if(start==NULL)
	{
		printf("\nstudent details are not entered\n");
	}
	else
	{
		printf("\nenter the rollno of student\n");
		scanf("%d",&loc);
		temp=start;
		count=1;
		while(temp!=NULL && temp->roll!=loc)
		{
			ptr=temp;
			count=count+1;
			temp=temp->next;
		}
			if(temp==NULL)
			{
				printf("\nparticular student don't belongs to our school\n");
			}
			else
			{
				ptr->next=temp->next;
				printf("\nstudent\n");
		printf("\nDeleted student\n");
		printf("\n\nRoll.NO:%d\nFirst Name:%s\nFirst Name:%s\nClass:%d\nTotal Marks:%f\npercentagecentage:%f\n", temp->roll,temp->firstname,temp->name,temp->class, temp->total_marks,((temp->percentage)/600)*100);
				free(temp);
				return;
			}
	}
}
