int main()
{
	int i;
	for(i=0;i<1000;i++)
	printf("siri\n");
}
