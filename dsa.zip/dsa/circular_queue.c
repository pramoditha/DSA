#include<stdio.h>
#include<stdlib.h>
#define size 20
void enqueue(int);
int dequeue();
void display();
int front=-1,rear=-1,queue[size],i,x;
int main()
{
	int ch,k;
	char c;
	printf("//////////////////MENU DRIVEN PROGRAM/////////////////////\n");
	printf("1.Enqueue\n2.Dequeue\n3.Display\n4.Exit\n");
	while(1)
	{
	printf("\nEnter choice:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:printf("\nEnter element to add:");
		scanf("%d",&x);
		enqueue(x);
		break;
		case 2:k=dequeue();
		       printf("Element poped from queue is %d\n",k);
		       break;
		case 3:display();
		break;
		case 4:return -1;
	}
}
}
void enqueue(int x)
{
   if((front==0 && rear==size-1) || (rear==front-1))
   {
   	printf("\nQueue is full!!");
   	return;
   }
   if(front ==-1)
   {
   	front=0;
   }
   rear++;
   rear=rear%size;
   queue[rear]=x;
   printf("\nElement Added");
}
int dequeue()
{
	if(front==-1)
	{
		printf("\nQueue is empty");
		return;
	}
	if(front==rear)
	{
		x=queue[front];
		front=-1;
		rear=-1;
	}
	else
	{
	x=queue[front];
	front++;
	front=front%size;
	}
	return x;
}
void display()
{
	if(front==-1)
	{
		printf("\nQueue is empty");
		return;
	}
	if(front<=rear)
	{
		for(i=front;i<=rear;i++)
		{
			printf("%4d",queue[i]);
		}
	}
	else
	{
		for(i=front;i<size;i++)
		{
			printf("%4d",queue[i]);
		}
		for(i=0;i<size;i++)
		{
			printf("%4d",queue[i]);
		}
		for(i=0;i<=rear;i++)
		{
			printf("%4d",queue[i]);
		}
	}
}
