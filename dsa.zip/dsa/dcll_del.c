#include<stdio.h>
#include<stdlib.h>
struct data_node
{
	int data;
	struct data_node *next;
	struct data_node *prev;
};

struct data_node *last=NULL;
void insert(int);
int deleteb();
int deletep(int );
int deletel();
void display();

int main()
{
	
	int x,ch,pos,i;
	do
	{
	printf("\n|-----------------------------------------------------------------|");
	printf("\n|                  MENU:                                          |");
	printf("\n|-----------------------------------------------------------------|");
	printf("\n|1.INSERTING/ADDING ELEMENTS AT THE BEGINING OF LINKED LIST       |");
	printf("\n|2.DELETING ELEMNTS AT THE BEGINING OF THE LINKED LIST            |");
	printf("\n|3.DELETING ELEMENTS AT THE SPECIFIED PLACE OF LINKED LIST        |");
	printf("\n|4.DELETING ELEMENTS AT THE END OF LINKED LIST                    |");
	printf("\n|5.DISPLAY                                                        |");
	printf("\n|6.EXIT                                                           |");
	printf("\n|-----------------------------------------------------------------|");
	printf("\n enter your choice from menu:");
	scanf("%d",&ch);
	switch(ch)
	{
		case 1:
			{
				printf("\n enter an integer to be added at the begining of the linked list:");
				scanf("%d",&x);
				insert(x);
				printf("\n element is added to the list");
				break;
			}
			
		case 2:
			{
				i=deleteb();
				if(i==-1)
				{
					printf("\n circular linked list is empty!!!");
				}
				else
				{
				printf("\n%d element is deleted from the circular linked list",i);
			    }
			}
			break;
			
		
		case 3:
			{
				printf("\n enter a position to be deleted:");
				scanf("%d",&pos);
				i=deletep(pos);
				printf("%d element is deleted from the  circular linked list",i);
			}
			break;
			
		case 4:
			{
				i=deletel();
				printf("%d element is deleted from the circular  linked list",i);
				break;
			}
		case 5:
			{
			   if(last==NULL)
				{
					printf("\n circular linked list is empty!!");
				}
				else
				{ 
				    display();
				}
			}
			break;
		case 6:
		   {
		   		printf("\nprogram has stopped");
		   		exit(0);
		   }
		default:
			{
				printf("\nyou have to select 1 to 6 to do linked list operations");
				break;
		    }	
	}
}while(ch!=6);

}


//code for inserting elements in linked list
void insert(int x)
{
		struct data_node *tp;
	tp=(struct data_node*)malloc(sizeof(struct data_node));
	if(tp==NULL)
	{
		printf("\nmemory is full or circular linked list is full.you cannot add the elements to circular linked list");
		return;
	}
	if(last==NULL)// empty
	{
	
	    tp->data=x;
    	tp->next=tp;// makes new node to point itself
    	tp->prev=tp;
    	last=tp;
   }
  else
  {
  	if(last->next==NULL)//one node
  	{
  		tp->data=x;
  		tp->next=last;
  		last->next=tp;
  		last->prev=last;
  		tp->prev=last;
  		
	}
	else
	{
  	 tp->data=x;
  	tp->next=last->next;
  	last->next->prev=tp;
  	last->next=tp;
  	tp->prev=last;
  }
  }
	


}

int deleteb()
{
	int x;
	struct data_node *tp;
	if(last==NULL)
	{
		return -1;
	}
    if(last==last->next)
    {
    	tp=last;
    	x=tp->data;
    	last=NULL;
	}
	else
	{
		tp=last->next;
		x=tp->data;
		last->next=tp->next;
		tp->next->prev=last;
		
	}
	free(tp);
	
	return x;//returned the second node address	
}

int deletep(int pos)
{
	int count=1,x;
	struct data_node *tp,*pp;
	pp=last->next;
       while(count<pos-1)
	   {
		 pp=pp->next;
		 count++;
	   }
	tp=pp->next;
	x=tp->data;
	pp->next=tp->next;
	tp->next->prev=pp;

	free(tp);
	
	return x;
}

int deletel()
{
	struct data_node *tp,*pp;
	int x;
	if(last==NULL)
	{
		printf("\n cll is empty!!");
		return;
	}
	if(last==last->next)
	{
		tp=last;
		x=tp->data;
		last=NULL;
	}
	else
	{
		tp=last;
		pp=last->next;
		while(pp->next!=last)
		{
			pp=pp->next;
		}
		pp->next=last->next;
		last->next->prev=pp;
		last=pp;
		x=tp->data;
		free(tp);
	}
	return x;
}

void display()
{
	// dispalying the elements of linked list
		struct data_node *tp;
	// dispalying the elements of linked list
	if(last==NULL)
	{
		printf("\n circular linked list is empty!!");
	}
	tp=last->next;// made tp pointer to point 1st node of the linked list
	
	printf("%4d<-->",(tp->data));
	tp=tp->next;
	while(tp!=last->next)
	{
		printf("%4d<-->",(tp->data));
		tp=tp->next;
	}

}
