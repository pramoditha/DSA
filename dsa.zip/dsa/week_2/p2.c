/*Linear search for ordered list*/
#include<stdio.h>
#include<stdlib.h>
int search(int [],int,int);
main()
{
	int a[100],n,key,r,i;
	printf("Enter n value");
	scanf("%d",&n);
	printf("Enter array elements in order:");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("Enter the element to be searched:");
	scanf("%d",&key);
	r=search(a,n,key);
	if(r!=-1)
	printf("Element found\nPlace=%d",r);
	else
	printf("Element not found");
}
int search(int a1[],int n,int key1)
{
	int i;
	for(i=0;i<n;i++)
	{
		if(a1[i]==key1)
		return i+1;
	}
	return -1;
}
