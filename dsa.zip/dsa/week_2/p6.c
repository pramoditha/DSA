/*Binary search strings*/
#include<stdio.h>
#include<stdlib.h>
int search(char [][20],int,char []);
main()
{
	int n,r,i;
	char x[20][20],key[20];
	printf("Enter n value");
	scanf("%d",&n);
	printf("Enter all ordered strings in a row:");
	for(i=0;i<n;i++)
	scanf("%s",&x[i]);
	printf("Enter the element to be searched:");
	scanf("%s",&key);
	r=search(x,n,key);
	if(r==-1)
	printf("Given element is not present in the list\n");
	else
	printf("The given Element is found at %d position in the list\n",r);
	return 0;
}
int search(char x[20][20],int n,char key1[])
{
	int low,high,mid,a;
	low=0;
	high=n-1;
	while(low<=high)
	{
    mid=(low+high)/2;
        a=strcmp(key1,x[mid]);
        if(a==0)
        {
            return mid+1;
        }
        else if(a<0)
        {
            high=mid-1;
        }
        else
        {
           	 low=mid+1;
		}
    }
    return -1;
}
