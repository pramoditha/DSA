/*Binary search with recursive function*/
#include<stdio.h>
#include<stdlib.h>
int search(int [],int,int,int);
main()
{
	int x[100],n,key,r,i,l=0,h;
	printf("Enter n value");
	scanf("%d",&n);
	printf("Enter all ordered integers in a row:");
	h=n-1;
	for(i=0;i<n;i++)
	scanf("%d",&x[i]);
    printf("Enter the string to be searched:");
	scanf("%d",&key);
	r=search(x,l,h,key);
	if(r==-1)
	printf("Element not found");
	else
	printf("Element found\nPlace=%d",r);
	return 0;
}
int search(int x[],int low,int high,int key)
{
	int mid;
     if (low<=high)
	{
    mid=(low+high)/2;
        if(key==x[mid])
        {
            return mid+1;
        }
        else if(key<x[mid])
        {
            return search(x,low,mid-1,key);
        }
        else
            return search(x,mid+1,high,key);
    }
    return -1;
}
