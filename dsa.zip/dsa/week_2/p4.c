/*Binary search without recursive function*/
#include<stdio.h>
#include<stdlib.h>
int search(int [],int,int);
main()
{
	int x[100],n,key,r,i;
	printf("Enter n value");
	scanf("%d",&n);
	printf("Enter all ordered integers in a row:");
	for(i=0;i<n;i++)
	scanf("%d",&x[i]);
	printf("Enter the element to be searched:");
	scanf("%d",&key);
	r=search(x,n,key);
	if(r==-1)
	printf("Given element is not present in the list\n");
	else
	printf("The given Element is found at %d position in the list\n",r);
	return 0;
}
int search(int x[],int n,int key)
{
	int low,high,mid;
	low=0;
	high=n-1;
	while(low<=high)
	{
    mid=(low+high)/2;
        if(key==x[mid])
        {
            return mid+1;
        }
        else if(key<x[mid])
        {
            high=mid-1;
        }
        else
            low=mid+1;
    }
    return -1;
}
