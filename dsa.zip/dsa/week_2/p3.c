/*Linear search for strings[unordered list]*/
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int search(char [][10],int,char[]);
main()
{
	int n,r,i;
	char x[10][10],key[10];
	printf("Enter no.of strings:");
	scanf("%d",&n);
	printf("Enter string elements:");
	for(i=0;i<n;i++)
	{
		scanf("%s",x[i]);
    }
	printf("Enter the string to be searched:");
	scanf("%s",key);
	r=search(x,n,key);
	if(r==-1)
	printf("Element not found");
	else
	printf("Element found\nPlace=%d",r);
	return 0;
}
int search(char x[10][10],int n,char key1[])
{
	int i,a;
	for(i=0;i<n;i++)
	{
		a=strcmp(x[i],key1);
		if(a==0)
		{
		return i+1;
	}
	}
	return -1;
}
