#include<stdio.h>
#include<stdlib.h>
#define SIZE 20
int harr[SIZE];
int node_cnt=0,n;
void insert(int x);
int Delete();
int del(int);
void display();
void heapify(int);
int main()
{
	int x,i,d,dl,v,ch;
	printf("\n Enter number of nodes in heap:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("\n Enter value %d:",i);
		scanf("%d",&x);
		insert(x);
	}
	printf("\n");
	while(ch!=4)
	{
		printf("\n 1.Delete heap node");
		printf("\n 2.Delete specified node");
		printf("\n 3.Display");
		printf("\n 4.Exit");
		printf("\n enter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:	d=Delete();
                    printf("\n %d is deleted",d);
                	display();
                	break;
	        case 2:printf("\n Enter a specified node to delete:");
                	scanf("%d",&dl);
                	v=del(dl);
                	printf("\n %d is deleted",v);
                	display();
                	break;
            case 3:display();
                   break;
            case 4:	printf("\n The program is stopped");
                 	break;
            default:
                    printf("Wrong choice \n");
		}
	}
	return 0;
}
void insert(int x)
{
	int i,j,temp;
	if(node_cnt==SIZE-1)
	{
		printf("\n Heap is full");
		return;
	}
	i=node_cnt;
	harr[i]=x;
	node_cnt++;
	j=i;
	while((j!=0)&&(harr[j]>harr[(j-1)/2]))
	{
		temp=harr[j];
		harr[j]=harr[(j-1)/2];
		harr[(j-1)/2]=temp;
		j=(j-1)/2;
	}
	printf("\n Your elements %d is added successfully\n",x);
	for(i=0;i<node_cnt;i++)
	{
		printf("%4d",harr[i]);
	}	
}
int Delete()
{
	int x=harr[0];
	int le=harr[n-1];
	harr[0]=le;
	n=n-1;
	heapify(0);
	return x;
}
int del(int dl)
{
	int i=0,x,v;
	for(i=0;i<n;i++)
	{
		if(dl==harr[i])
		{
			v=harr[i];
	    	x=i;	
		}		
	}
	int le=harr[n-1];
	harr[x]=le;
	n=n-1;
	heapify(0);
	return v;
}
void heapify(int i)
{
	int large=i,temp;
	int l=2*i+1;
	int r=2*i+2;
	if(l<n&&harr[l]>harr[large])
	{
		large=l;
	}
	if(r<n&&harr[r]>harr[large])
	{
		large=r;
	}
	if(large!=i)
	{
		temp=harr[i];
		harr[i]=harr[large];
		harr[large]=temp;
		heapify(large);
	}
}
void display()
{
	int i;
	printf("\n The heap elements:");
	for(i=0;i<n;i++)
	{
		printf("%4d",harr[i]);
	}
}
