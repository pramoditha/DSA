#include<stdio.h>
#include<stdlib.h>
void merge_sort(int [],int,int);
void merge(int [],int,int,int);
main()
{
	int a[20],n,i,j;
	int l=0;
	printf("Enter how many intergers are there:");
	scanf("%d",&n);
	printf("\nEnter all the integers in a row:\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("\nThe elements before sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	merge_sort(a,l,n-1);
	printf("\nThe elements after sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	return 0;
}
void merge_sort(int x[],int lb,int ub)
{
	if(lb>=ub)
	return;
	int mid=(lb+ub)/2;
	merge_sort(x,lb,mid);
	merge_sort(x,mid+1,ub);
	merge(x,lb,mid,ub);
}
void merge(int x[],int lb,int mid,int ub)
{
	int i,j,n1,n2,k;
	n1=mid-lb+1;
	n2=ub-mid;
	int t1[n1],t2[n2];
	for(i=0;i<n1;i++)
	{
		t1[i]=x[lb+i];
	}
	for(j=0;j<n2;j++)
	{
		t2[j]=x[mid+1+j];
	}
	i=0;
	j=0;
	k=lb;
	while(i<n1 && j<n2)
	{
		if(t1[i]<t2[j])
		{
		x[k]=t1[i];
		i++;
	}
		else
		{
		x[k]=t2[j];
		j++;
	}
	k++;
	}
	while(i<n1)
	{
		x[k]=t1[i];
		k++;
		i++;
	}
	while(j<n2)
	{
		x[k]=t2[j];
		k++;
		j++;
	}
}
