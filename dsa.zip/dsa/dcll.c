#include<stdio.h>
#include<stdlib.h>
struct dcll
{
	int data;
	struct dcll *next;
	struct dcll *prev;
}*last=NULL;
void add(int);
void dis();
int main()
{
	int xs,n;
	printf("\n\n\n1.Add an element.");
	printf("\n2.Display  elements.");
	printf("\n3.Exit");
	printf("\nEnter your Choice:");
	scanf("%d",&xs);
	do
	{
		switch(xs)
		{
			case 1:printf("Enter element:");
			scanf("%d",&n);
			add(n);
			break;
			case 2:display();
			break;
			case 3:return -1;
		}
	}while(xs!=3);
}
void add(int x)
{
	struct dcll *tp;
	tp=(struct dcll *)malloc(sizeof(struct dcll));
	if(tp==NULL)
	{
		printf("\nLinked List is Full");
		return;
	}
	if(last==NULL)
	{
	tp->data=x;
	tp->next=tp;
	tp->prev=tp;
	last=tp;
}
	else 
{
	if(next==prev)
	{
		tp->data=x;
		tp->next=last;
		
	}
}
	printf("\nYour data is successfully added into double linked list");
}  
