#include<stdio.h>
#include<stdlib.h>
int oprand(char);
void push(char);
char pop();
int priority(char);
char stk[20],k;
int top=-1;
int main()
{
	char e[20],*ep,c;
	int i=0;
	scanf("%s",e);
	ep=e;
	while(*ep!='\0')
	{
		if(oprand(*ep)==1)
		printf("%c",*ep);
		else if(*ep=='(')
		push(*ep);
		else if(*ep==')')
		{
			while(c!='(')
			{
				c=pop();
				if(c!='(')
				printf("%c",c);
				if(top==-1)
				break;
			}
		}
		else
		{
			if(top!=-1)
			{
			while(priority(*ep)<=priority(stk[top]))
			{
				printf("%c",pop());
				if(top==-1)
				break;
			}
			push(*ep);
		}
		else
		push(*ep);
		}
		ep++;
	}
	while(top!=-1)
	{
		if(pop()!='(')
		printf("%c",pop());
	}
}
int oprand(char c)
{
	if(c>='a' && c<='z')
	return 1;
	else
	return 0;
}
char pop()
{
	k=stk[top--];
	return k;
}
void push(char c)
{
	stk[++top]=c;
}
int priority(char c)
{
	if(c=='(')
	return 0;
	else if(c=='+' || c=='-')
	return 1;
	else 
	return 2;
}
