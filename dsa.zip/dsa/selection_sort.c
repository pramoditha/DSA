#include<stdio.h>
#include<stdlib.h>
void selection_sort(int [],int);
main()
{
	int a[20],n,i,j;
	printf("Enter how many intergers are there:");
	scanf("%d",&n);
	printf("\nEnter all the integers in a row:\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	printf("\nThe elements before sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	selection_sort(a,n);
	printf("\nThe elements after sorting:\n");
	for(i=0;i<n;i++)
	printf("%5d",a[i]);
	return 0;
}
void selection_sort(int x[],int n)
{
	int large,index,i,j;
	for(i=n-1;i>=1;i--)
	{
		large=x[0];
		index=0;
		for(j=1;j<=i;j++)
		{
			if(large<x[j])
			{
				large=x[j];
				index=j;
			}
		}
		x[index]=x[i];
		x[i]=large;
	}
}
