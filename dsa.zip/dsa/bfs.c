#include<stdio.h>
#include<stdlib.h>
void BFS(int);
int graph[10][10],visited[10],total;
int main()
{
	int i,j;
	printf("\n Enter no.of vertices: ");
	scanf("%d",&total);
	printf("\n Enter Adjacency matrix for a Graph: ");
	for(i-0;i<total;i++)
	{
		for(j=0;j<total;j++)
		{
			scanf("%d",&graph[i][j]);
		}
	}
	for(i=0;i<total;i++)
	{
		visited[i]=0;
	}
	printf("\n BFS Traversal is: ");
	BFS(0);
}
void BFS(int vertex)
{
	int j;
	printf("\n %d",vertex);
	visited[vertex]=1;
	for(j=0;j<total;j++)
	{
		if(!visited[j] && graph[vertex][j]==1)
		{
			BFS(j);
		}
	}
}
