#include<stdio.h>
#include<stdlib.h>
#define SIZE 100
int minpq[100],front=-1,rear=-1;
void enqueue(int);
int dequeue();
void display();
int min();
int main()
{
	int ch,n;
    do
    {
    	printf("\n1.Enqueue\n");
    	printf("2.Dequeue\n");
    	printf("3.Traversal\n");
    	printf("4.Exit\n");
    	printf("Enter Choice:");
    	scanf("%d",&ch);
    	switch(ch)
    	{
    		case 1:printf("Enter the element to be added:");
    		scanf("%d",&n);
    		enqueue(n);
    		break;
    		case 2:n=dequeue();
    		printf("Element Deleted is %d",n);
    		break;
    		case 3:display();
    		break;
    		case 4:return -1;
		}
	}while(ch!=4);
}
void enqueue(int x)
{
	if(rear==SIZE-1)
	{
	printf("Queue Is Full!!");
	return;
}
     rear=rear+1;
     minpq[rear]=x;
   if(rear==0)
{
	 front=0;
}
   return;
}
int dequeue()
{
	int x,i;
	if (rear==-1 || front>rear)
	{
		printf("Queue Is Empty!!!");
		return;
	}
	int pos;
	pos=min();
	x=minpq[pos];
	minpq[pos]=minpq[front];
	minpq[front]=x;
	front=front+1;
	return x;
}
int min()
{
	int small,i,ind;
	small=minpq[front];
	ind=front;
	for(i=front+1;i<=rear;i++)
	{
		if(small>minpq[i])
		{
			small=minpq[i];
			ind=i;
		}
	}
	return ind;
}
void display()
{
	int i;
	for(i=front;i<=rear;i++)
	{
		printf("%4d",minpq[i]);
	}
}
