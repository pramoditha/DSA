#include<stdio.h>
#include<stdlib.h>
struct dll
{
	int data;
	struct dll *next;
	struct dll *prev;
};
struct dll *head=NULL;
void add(int);
void dis();
int del();
int xs,cs,k;
int main()
{
	int n,x,i,k;
	printf("Enter no.of elements:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&x);
		add(x);
	}
	printf("Displaying before deletion\n");
	dis();
	del();
	printf("\nDisplaying in after deletion\n");
	dis();
}
void add(int x)
{
	struct dll *tp;
	tp=(struct dll *)malloc(sizeof(struct dll));
	if(tp==NULL)
	{
		printf("\nDouble Linked List is full");
		return;
	}
	tp->data=x;
	tp->next=head;
	if(head!=NULL)
	{
		
		head->prev=tp;
	}
	tp->prev=NULL;
	head=tp;
}
void dis()
{
	struct dll *tp;
	if(head==NULL)
	{
		printf("\ndll is empty");
		return;
	}
	tp=head;
	while(tp!=NULL)
	{
		printf("%d==>",tp->data);
		tp=tp->next;
	}
}
int del()
{
//	printf("jjjjj");
	struct dll *tp,*pp;
	tp=head;
	int n=1;
	while(tp!=NULL)
	{
		n++;
		printf("k%d",n);
		pp=tp->next;
		while(pp!=NULL)
		{   
		printf("d%d",n); 
		if(tp->data==pp->data)
		{
			printf("Found");
		while(pp->next!=NULL)
		{
			pp=pp->next;
			printf("Delted");
		}
		pp=NULL;
		break;
	}
    pp=pp->next;
       }
tp=tp->next;
}
}
