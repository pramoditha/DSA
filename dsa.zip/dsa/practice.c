#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node *next;
};
struct node * cll(struct node *,int);
struct node * insert(struct node *,int);
void display(struct node *);
int count(struct node *);
int search(struct node *,int);
struct node * del(struct node *);
int main()
{
	struct node *hp=NULL;
	int ch,x,k;
	do
	{
		printf("\n1.Cll\n2.Insert\n3.delet\n4.Display\n");
		printf("Enter choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:printf("Enter Value to create:");
			scanf("%d",&x);
			hp=cll(hp,x);
			break;
			case 2:printf("Enter Value to add:");
			scanf("%d",&x);
			hp=insert(hp,x);
			break;
			case 3:hp=del(hp);
			break;
			case 4:display(hp);
			break;
			case 5:k=count(hp);
			printf("COUNT=%d",k);
		    break;
		    case 6:printf("ENter key:");
		    scanf("%d",&x);
		    k=search(hp,x);
		    if(k!=-1)
		    printf("Found at %d",k);
		    else
		    printf("Not FOund");
			case 7:return -1; 	
		}
	}while(ch!=8);
}
struct node * cll(struct node *hp,int x)
{
	struct node *tp;
	tp=(struct node*)malloc(sizeof(struct node));
	tp->data=x;
	tp->next=hp;
	hp=tp;
	return hp;
}
struct node * insert(struct node *hp,int x)
{
	struct node *tp;
	tp=(struct node*)malloc(sizeof(struct node));
	tp->data=x;
	tp->next=hp;
	hp=tp;
	return hp;
}
struct node * del(struct node *hp)
{
	struct node *tp;
	tp=hp;
	hp=tp->next;
	free(tp);
	return hp;
}
void display(struct node *hp)
{
	struct node *tp;
	tp=hp;
	while(tp!=NULL)
	{
		printf("|%d|----->",tp->data);
		tp=tp->next;
		if(tp==NULL)
		return;
	}
	printf("NULL");
	printf("\n\n");
}
int count(struct node *hp)
{
	struct node *tp;
	int c=0;
	tp=hp;
	while(tp!=NULL)
	{
		c++;
		tp=tp->next;
	}
	return c;
}
int search(struct node *hp,int x)
{
	struct node *tp;
	int p=1;
	tp=hp;
	while(tp!=NULL)
	{
		if(tp->data==x)
		return p;
		else
		{
			p++;
		tp=tp->next;
	}
	}
	return -1;
}
