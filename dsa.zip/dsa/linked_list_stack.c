#include<stdio.h>
#include<stdlib.h>
struct node
{
	int data;
	struct node*next;
}*new,*temp,*top=NULL;
void push(int);
void pop();
void display();
void exit(int);
int main()
{
	int ele,choice;
	while(1)
	{
		printf("\n1.push\n2.pop\n3.display\n4.exit");
		printf("\nenter your choice");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1:printf("\nenter an element");
			scanf("%d",&ele);
			push(ele);
			break;
			case 2:pop();
			break;
			case 3:display();
			break;
			case 4:exit(0);
			break;
			default:printf("\nwrong selection try again");
			break;
		}
	}
}
void push(int ele)
{
	new=(struct node*)malloc(sizeof(struct node));
	if(top==NULL)
	{
		new->data=ele;
		new->next=NULL;
		top=new;
	}
	else
	{
		new->data=ele;
		new->next=top;
		top=new;
	}
}
void pop()
{
	if(top==NULL)
	{
		printf("\nstack is empty");
	}
	else
	{
		int ele;
		temp=top;
		ele=top->data;
		printf("\n%d is deleted",ele);
		top=top->next;
		temp->next=NULL;
		free(temp);
	}
}
void display()
{
	if(top==NULL)
	{
		printf("\nstack is empty");
	}
	else
	{
		temp=top;
		while(temp!=NULL)
		{
			printf("%d\t",temp->data);
			temp=temp->next;
		}
	}
}
