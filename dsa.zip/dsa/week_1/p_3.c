#include<stdio.h>
struct student
{
	int ht;
	char name[10];
	int sub[6];
	int t;
	int p1;
};
main()
{
	struct student s[10],*p[10];
	int i,n,j;
	printf("Enter no.of students:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	p[i]=&s[i];
	for(i=0;i<n;i++)
	{
		printf("Enter Student-%d",i+1);
		printf("\nEnter hall-ticket Number:");
		scanf("%d",&p[i]->ht);
		printf("Enter Name:");
		scanf("%s",p[i]->name);
		printf("Enter marks in order\n");
		for(j=0;j<6;j++)
		scanf("%d",&p[i]->sub[j]);
	}
	for(i=0;i<n;i++)
	{
		p[i]->t=0;
		for(j=0;j<6;j++)
		p[i]->t=p[i]->t+p[i]->sub[j];
		p[i]->p1=p[i]->t/6;
}
printf("-----------Student Details-----------\n");
printf("H-T Num\tName\tsm1  sm2  sm3  sm4  sm5  sm6  Total\tPercentage\n");
	for(i=0;i<n;i++)
	{
		printf("%d\t%s  ",p[i]->ht,p[i]->name);
		for(j=0;j<6;j++)
		printf("    %d",p[i]->sub[j]);
	    printf("%5d\t%5d\n",p[i]->t,p[i]->p1);
	}
}
