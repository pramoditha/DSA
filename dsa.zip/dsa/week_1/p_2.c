#include<stdio.h>
struct student
{
	int ht;
	char name[10];
	int sub[6];
	int t;
	int p;
}s[10];
main()
{
	int i,n,j;
	printf("Enter no.of students:");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Enter Student-%d",i+1);
		printf("\nEnter hall-ticket Number:");
		scanf("%d",&s[i].ht);
		printf("Enter Name:");
		scanf("%s",s[i].name);
		printf("Enter marks in order\n");
		for(j=0;j<6;j++)
		scanf("%d",&s[i].sub[j]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<6;j++)
		s[i].t=s[i].t+s[i].sub[j];
		s[i].p=s[i].t/6;
}
printf("-----------Student Details-----------");
	for(i=0;i<n;i++)
	{
		printf("\n\nStudent-%d",i+1);
		printf("\nHall-ticket Number:%d",s[i].ht);
		printf("\nName:%s",s[i].name);
		printf("\n///////Marks in order////////\n");
		for(j=0;j<6;j++)
		{ 
		printf("     Sub-%d",j+1);
		printf("%5d\n",s[i].sub[j]);
	}
	printf("Total:%d\nPercentage:%d\n\n",s[i].t,s[i].p);
	}
}

