#include<stdio.h>
void swap(int,int);
main()
{
	int a,b;
	printf("Enter a and b:");
	scanf("%d%d",&a,&b);
	printf("Before Swap\na:%d\nb:%d",a,b);
	swap(a,b);
	printf("\nAfter Swap\na:%d\nb:%d",a,b);
}
void swap(int a,int b)
{
	int t;
	t=a;
	a=b;
	b=t;
	printf("\nIn Swap Function\na:%d\nb:%d",a,b);
}
