#include<stdio.h>
main()
{
	int a[10],lar=0,sma=99999,n,i;
	printf("enter n value:");
	scanf("%d",&n);
	printf("Enter array elements:\n");
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++)
	{
		if(a[i]>lar)
		lar=a[i];
		if(a[i]<sma)
		sma=a[i];
		printf("%3d",a[i]);
	}
	printf("\nLargest Element:%d\nSmallest Element:%d",lar,sma);
}
