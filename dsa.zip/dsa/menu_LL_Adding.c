#include<stdlib.h>
#include<stdio.h>
struct Data_Node
{
	int data;
	struct Data_Node *next;
};
struct Data_Node * insert(struct Data_Node *, int);
void display(struct Data_Node *);
struct Data_Node* insert_last(struct Data_Node *,int);
struct Data_Node * insert_node(struct Data_Node *,int,int );
int main()
{
	struct Data_Node *hp=NULL;
	int ch,x,n;
	do
	{
    	printf("\n 1. Adding a linked List at the beginning    ");
    	printf("\n 2. Adding element at specified position     ");
        printf("\n 3. Adding element at the end                ");	
		printf("\n 4. Displaying a linked List                 ");
    	printf("\n 5. Quit                                     ");
    	printf("\n\n Enter your choice from menu:");
    	scanf("%d",&ch);
	switch(ch)
	{
		case 1:printf("\n Enter an integer to be added in a linked list:");
		       scanf("%d",&x);
		       hp=insert(hp,x);
		       break;
		case 2:printf("\n Enter position at which you want to add data in a linked list:");
		       scanf("%d",&n);
		       printf("\n Enter an integer to be added in a linked list:");
		       scanf("%d",&x);
		       
		       hp=insert_node(hp,x,n);
		       break;
	    case 3:printf("\n Enter an integer to be added in a linked list:");
		       scanf("%d",&x);
		       hp=insert_last(hp,x);
		       break;
		case 4:if( hp== NULL)
	        	{
	        		printf("\n Linked list is empty");
	        	}
	        	else
	        	{
	        		printf("\n The element in linked list are: \n");
	        		display(hp);
				}
				break;
		case 5:printf("\n This program is stopped now...!!\n");
		       break;
		
		default:printf("\nWrong choice\n");
	            break;
	}
	}while(ch!=5);
}
struct Data_Node * insert(struct Data_Node *hp,int x)
{
	struct Data_Node *tp;
	tp=(struct Data_Node *)malloc(sizeof(struct Data_Node));
	if(tp == NULL)
	{
		printf("\n linked list is full, you cannot add elements");
		return 0;
	}
	tp->data = x;
	tp->next = hp;
	hp=tp;
	printf("\n Your data is successfully added to the linked list\n");
	return hp;
}
struct Data_Node * insert_node(struct Data_Node *hp, int x,int n)
{	
    struct Data_Node *tp,*xp;
    xp=hp;
    int count=1;
	while(count<n-1)
	{	
		xp=xp->next;
		count++;
	}
	tp=(struct Data_Node *)malloc(sizeof(struct Data_Node));
	tp->data=x;
	tp->next=xp->next;
	xp->next=tp;
	printf("\n Your data is successfully added at %d position to the linked list\n",x);
	return hp;
}
struct Data_Node * insert_last(struct Data_Node *hp,int x)
{
	struct Data_Node *tp,*xp;
	xp=hp;
	while(xp->next!=NULL)
	{	
    	xp=xp->next;
	}
	tp=(struct Data_Node *)malloc(sizeof(struct Data_Node));
	tp->data=x;
	tp->next=NULL;
	xp->next=tp;
	return(hp);
}
void display(struct Data_Node *hp)
{
	struct Data_Node *tp;
	tp = hp;
	while( tp!=NULL)
	{
		printf("| %4d |--->",tp->data);
		tp=tp->next;
	}
	printf("NULL");
	printf("\n\n");
}
