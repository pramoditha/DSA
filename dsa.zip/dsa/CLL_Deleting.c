#include<stdio.h>
#include<stdlib.h>
struct cll
{
	int data;
	struct cll * next;
	struct cll* last;
}*last=NULL;
struct cll * AddAtStart(int);
int DelAtStart();
int DeltEnd();
int DelAtMiddle(int);
int x;
void display();
int main()
{
	int ch,x,pos,k;
	do
	{
		printf("\n|----------------------------------------------------------------|");
		printf("\n|                     MENU                                       |");
		printf("\n|----------------------------------------------------------------|");
		printf("\n|1.Adding an element at Beginning                                |");
		printf("\n|2.Deleting an element at Beginning                              |");
		printf("\n|3.Deleting an element at End                                    |");
		printf("\n|4.Deleting an element at Specified Position                     |");
		printf("\n|5.Display                                                       |");
		printf("\n|                    6.Exit                                      |");
    	printf("\n|----------------------------------------------------------------|");
    	printf("\nEnter choice:");
    	scanf("%d",&ch);
    	switch(ch)
    	{
    		case 1:printf("\nEnter a number to add:");
    		scanf("%d",&x);
    		AddAtStart(x);
    		break;
    		case 2:k=DelAtStart();
    		printf("%d is deleted",k);
    		break;
    		case 3:k=DelAtEnd();
    		printf("%d is deleted",k);
    		break;
    		case 4:printf("\nEnter position to be deleting:");
    		scanf("%d",&pos);
    		k=DelAtMiddle(pos);
    		printf("%d is deleted",k);
    		break;
    		case 5:display();
    		break;
    		case 6:printf("\nYour program is stopped");
    		return -1;
		}
	}while(ch!=6);
}
struct cll * AddAtStart(int x)
{
	struct cll *tp;
	tp=(struct cll *)malloc(sizeof(struct cll));
	if(tp==NULL)
	{
		printf("\nLinked List is Full");
		return;
	}
	if(last== NULL)
	{
		tp->data=x;
		tp->next=tp;
		last=tp;
	}
	else
	{
		tp->data=x;
		tp->next=last->next;
		last->next=tp;
	}
	printf("Your Element is added at begging\n");
}
int DelAtStart()
{
	struct cll *tp;
	if(last==NULL)
	{
		printf("\nCLL is empty");
		return;
	}
	if(last==last->next)
	{
		tp=last;
		x=tp->data;
		last=NULL;
	}
	else
	{
		tp=last->next;
		last->next=tp->next;
		x=tp->data;
	}
	free(tp);
	return x;
}
int DelAtEnd()
{
	int x;
	struct cll *tp,*pp;
	if(last==NULL)
	{
		printf("\nCLL is empty");
		return;
	}
	if(last==last->next)
	{
		tp=last;
		x=tp->data;
		last=NULL;
	}
	else
	{
		tp=last;
		pp=last->next;
		while(pp->next!=last)
		pp=pp->next;
		pp->next=last->next;
		last=pp;
		x=tp->data;
		free(tp);
		return x;
	}
	free(tp);
	return x;
}
int DelAtMiddle(int pos)
{
	int x;
	struct cll *tp,*pp;
	pp=last->next;
	x=1;
	while(x<pos-1)
	{
		pp=pp->next;
		x++;
	}
	tp=pp->next;
	pp->next=tp->next;
	x=tp->data;
	free(tp);
	return x;
}
void display()
{
	struct cll *tp;
	if(last == NULL)
	{
		printf("\nCLL is empty");
		return;
	}
	tp=last->next;
	do
	{
		printf("%4d---->",tp->data);
		tp=tp->next;
	}while(tp!=last->next);
}
