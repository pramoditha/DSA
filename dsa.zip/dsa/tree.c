#include<stdio.h>
#include<stdlib.h>
struct tnode
{
	int data;
	struct tnode *left;
	struct tnode *right;
};
struct tnode * root=NULL;
struct tnode * insert(int);
int main()
{
	root=insert(10);
	root->left=insert(20);
	root->right=insert(30);
	root->left->left=insert(40);
	printf("\nThe given tree is created");
	printf("\nThe tree values are:");
	printf("\nroot=%d",root->data);
	printf("\nroot->left=%d",root->left->data);
	printf("\nroot->right=%d",root->right->data);
	printf("\nroot->left->left=%d",root->left->left->data);
}
struct tnode * insert(int x)
{
	struct tnode *tp;
	tp=(struct tnode *)malloc(sizeof(struct tnode));
	tp->data=x;
	tp->left=NULL;
	tp->right=NULL;
	return tp;
}
